package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

private data class PlayerStatDraft(
    val runs: String = "",
    val balls: String = "",
    val fours: String = "",
    val sixes: String = "",
    val isNotOut: Boolean = false,
    val oversBowled: String = "",
    val runsConceded: String = "",
    val wickets: String = ""
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ManualScoringScreen(
    matchId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val strings = LocalAppStrings.current
    val match = uiState.allMatches.firstOrNull { it.id == matchId }

    if (match == null) {
        Scaffold(topBar = { ScreenTopBar(title = strings.manualScoring, onBack = onBack) }) { p ->
            Text("Match not found", modifier = Modifier.padding(p).padding(20.dp))
        }
        return
    }

    val teamAPlayers = uiState.allPlayers.filter { it.tournamentId == match.tournamentId && it.teamId == match.teamAId }
    val teamBPlayers = uiState.allPlayers.filter { it.tournamentId == match.tournamentId && it.teamId == match.teamBId }
    val matchPlayers = teamAPlayers + teamBPlayers
    val existingStats = uiState.allPlayerMatchStats.filter { it.matchId == match.id }

    var aRuns by remember(match.id) { mutableStateOf(match.teamARuns.toString()) }
    var aWkts by remember(match.id) { mutableStateOf(match.teamAWickets.toString()) }
    var aOvers by remember(match.id) { mutableStateOf(CricketStatsEngine.formatOvers(match.teamABalls)) }
    var aExtras by remember(match.id) { mutableStateOf(match.teamAExtras.toString()) }

    var bRuns by remember(match.id) { mutableStateOf(match.teamBRuns.toString()) }
    var bWkts by remember(match.id) { mutableStateOf(match.teamBWickets.toString()) }
    var bOvers by remember(match.id) { mutableStateOf(CricketStatsEngine.formatOvers(match.teamBBalls)) }
    var bExtras by remember(match.id) { mutableStateOf(match.teamBExtras.toString()) }

    val statDrafts = remember(match.id, existingStats.size) {
        mutableStateMapOf<Long, PlayerStatDraft>().apply {
            matchPlayers.forEach { p ->
                val prev = existingStats.firstOrNull { it.playerId == p.id }
                put(
                    p.id,
                    if (prev != null) {
                        PlayerStatDraft(
                            runs = if (prev.runsScored > 0 || prev.didBat) prev.runsScored.toString() else "",
                            balls = if (prev.ballsFaced > 0) prev.ballsFaced.toString() else "",
                            fours = if (prev.fours > 0) prev.fours.toString() else "",
                            sixes = if (prev.sixes > 0) prev.sixes.toString() else "",
                            isNotOut = prev.isNotOut,
                            oversBowled = if (prev.ballsBowled > 0) CricketStatsEngine.formatOvers(prev.ballsBowled) else "",
                            runsConceded = if (prev.runsConceded > 0 || prev.didBowl) prev.runsConceded.toString() else "",
                            wickets = if (prev.wicketsTaken > 0) prev.wicketsTaken.toString() else ""
                        )
                    } else {
                        PlayerStatDraft()
                    }
                )
            }
        }
    }

    var selectedTeamTab by remember { mutableIntStateOf(0) }
    var battingFirstTeamId by remember(match.id) {
        mutableStateOf(if (match.battingFirstTeamId == match.teamBId) match.teamBId else match.teamAId)
    }
    var autoSelectPom by remember(match.id) { mutableStateOf(match.playerOfMatchId == 0L) }
    var manualPom by remember(match.id) {
        mutableStateOf(
            matchPlayers.firstOrNull { it.id == match.playerOfMatchId } ?: matchPlayers.firstOrNull()
        )
    }
    var customResult by remember(match.id) { mutableStateOf("") }
    var superOverWinnerId by remember(match.id) { mutableStateOf(match.winnerTeamId) }

    val manualTournament = uiState.tournaments.firstOrNull { it.id == match.tournamentId }
    val playersPerSideLimit = CricketStatsEngine.effectivePlayersPerSideForMatch(match, manualTournament)
    val initialTeamAPlaying = remember(match.id, existingStats.size) {
        val saved = CricketStatsEngine.parsePlayingIds(match.teamAPlayingIds)
        if (saved.isNotEmpty()) saved
        else existingStats.filter { it.teamId == match.teamAId }.map { it.playerId }.distinct()
    }
    val initialTeamBPlaying = remember(match.id, existingStats.size) {
        val saved = CricketStatsEngine.parsePlayingIds(match.teamBPlayingIds)
        if (saved.isNotEmpty()) saved
        else existingStats.filter { it.teamId == match.teamBId }.map { it.playerId }.distinct()
    }
    var selectedTeamAIds by remember(match.id, existingStats.size) { mutableStateOf(initialTeamAPlaying) }
    var selectedTeamBIds by remember(match.id, existingStats.size) { mutableStateOf(initialTeamBPlaying) }
    var manualValidationError by remember(match.id) { mutableStateOf<String?>(null) }

    val draftStatsForImpact = matchPlayers.map { p ->
        val d = statDrafts[p.id] ?: PlayerStatDraft()
        val r = d.runs.toIntOrNull() ?: 0
        val b = d.balls.toIntOrNull() ?: 0
        val f4 = d.fours.toIntOrNull() ?: 0
        val s6 = d.sixes.toIntOrNull() ?: 0
        val bowlBalls = CricketStatsEngine.parseOversToBalls(d.oversBowled)
        val conc = d.runsConceded.toIntOrNull() ?: 0
        val wkts = d.wickets.toIntOrNull() ?: 0
        val didBat = r > 0 || b > 0 || f4 > 0 || s6 > 0 || d.isNotOut
        val didBowl = bowlBalls > 0 || conc > 0 || wkts > 0
        PlayerMatchStatEntity(
            tournamentId = match.tournamentId,
            matchId = match.id,
            teamId = p.teamId,
            playerId = p.id,
            playerName = p.name,
            innings = if (p.teamId == battingFirstTeamId) 1 else 2,
            didBat = didBat,
            runsScored = r,
            ballsFaced = b,
            fours = f4,
            sixes = s6,
            isNotOut = d.isNotOut,
            didBowl = didBowl,
            ballsBowled = bowlBalls,
            runsConceded = conc,
            wicketsTaken = wkts
        )
    }
    val impactByPlayerId = CricketStatsEngine.calculateMatchStatsImpact(draftStatsForImpact, manualTournament)
    val liveImpactRankings = matchPlayers.map { p ->
        p to (impactByPlayerId[p.id]?.totalScore ?: 0.0)
    }.sortedByDescending { it.second }
    val liveImpactMap = liveImpactRankings.toMap()
    val autoTopPerformer = liveImpactRankings.firstOrNull()
    val effectivePom = if (autoSelectPom) (autoTopPerformer?.first ?: manualPom) else manualPom

    val activeSquad = if (selectedTeamTab == 0) teamAPlayers else teamBPlayers
    val activeTeamName = if (selectedTeamTab == 0) match.teamAName else match.teamBName
    val liveErrA = CricketStatsEngine.validatePlayingSelection(selectedTeamAIds, playersPerSideLimit)
    val liveErrB = CricketStatsEngine.validatePlayingSelection(selectedTeamBIds, playersPerSideLimit)

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = strings.manualScoring,
                subtitle = "${match.teamAName} vs ${match.teamBName}",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("আগে ব্যাট করেছে (Batting First)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            SegmentedButton(
                                selected = battingFirstTeamId == match.teamAId,
                                onClick = { battingFirstTeamId = match.teamAId },
                                shape = SegmentedButtonDefaults.itemShape(0, 2)
                            ) { Text(match.teamAName, maxLines = 1) }
                            SegmentedButton(
                                selected = battingFirstTeamId == match.teamBId,
                                onClick = { battingFirstTeamId = match.teamBId },
                                shape = SegmentedButtonDefaults.itemShape(1, 2)
                            ) { Text(match.teamBName, maxLines = 1) }
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(match.teamAName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = aRuns, onValueChange = { aRuns = it.filter { c -> c.isDigit() } }, label = { Text("Runs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = aWkts, onValueChange = { aWkts = it.filter { c -> c.isDigit() } }, label = { Text("Wkts") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = aOvers,
                                onValueChange = { aOvers = it; manualValidationError = null },
                                label = { Text("Overs (e.g. 8.0)") },
                                isError = !CricketStatsEngine.isValidOversInput(aOvers),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(value = aExtras, onValueChange = { aExtras = it.filter { c -> c.isDigit() } }, label = { Text("Extras") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        OutlinedButton(
                            onClick = {
                                val sum = teamAPlayers.sumOf { statDrafts[it.id]?.runs?.toIntOrNull() ?: 0 } + (aExtras.toIntOrNull() ?: 0)
                                aRuns = sum.toString()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Auto-sum ${match.teamAName} Runs from Players") }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(match.teamBName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = bRuns, onValueChange = { bRuns = it.filter { c -> c.isDigit() } }, label = { Text("Runs") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(value = bWkts, onValueChange = { bWkts = it.filter { c -> c.isDigit() } }, label = { Text("Wkts") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = bOvers,
                                onValueChange = { bOvers = it; manualValidationError = null },
                                label = { Text("Overs (e.g. 8.0)") },
                                isError = !CricketStatsEngine.isValidOversInput(bOvers),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(value = bExtras, onValueChange = { bExtras = it.filter { c -> c.isDigit() } }, label = { Text("Extras") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                        }
                        OutlinedButton(
                            onClick = {
                                val sum = teamBPlayers.sumOf { statDrafts[it.id]?.runs?.toIntOrNull() ?: 0 } + (bExtras.toIntOrNull() ?: 0)
                                bRuns = sum.toString()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Auto-sum ${match.teamBName} Runs from Players") }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "একাদশ বাছাই (ঠিক $playersPerSideLimit জন প্রতি দলে)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "ব্যাট বা বল না করলেও একাদশে থাকা খেলোয়াড়ের ম্যাচ সংখ্যা যোগ হবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val activeSelIds = if (selectedTeamTab == 0) selectedTeamAIds else selectedTeamBIds
                        val activeLimitErr = if (selectedTeamTab == 0) liveErrA else liveErrB
                        Text(
                            "$activeTeamName বাছাই: ${activeSelIds.size} / $playersPerSideLimit",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (activeLimitErr != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        if (activeLimitErr != null) {
                            Text(
                                text = activeLimitErr,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            activeSquad.forEach { p ->
                                val checked = p.id in activeSelIds
                                FilterChip(
                                    selected = checked,
                                    onClick = {
                                        manualValidationError = null
                                        if (selectedTeamTab == 0) {
                                            selectedTeamAIds = if (checked) selectedTeamAIds - p.id else selectedTeamAIds + p.id
                                        } else {
                                            selectedTeamBIds = if (checked) selectedTeamBIds - p.id else selectedTeamBIds + p.id
                                        }
                                    },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Individual Player Batting & Bowling (${activeTeamName})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = selectedTeamTab == 0,
                            onClick = { selectedTeamTab = 0 },
                            shape = SegmentedButtonDefaults.itemShape(0, 2)
                        ) { Text(match.teamAName, maxLines = 1) }
                        SegmentedButton(
                            selected = selectedTeamTab == 1,
                            onClick = { selectedTeamTab = 1 },
                            shape = SegmentedButtonDefaults.itemShape(1, 2)
                        ) { Text(match.teamBName, maxLines = 1) }
                    }
                }
            }

            items(activeSquad, key = { it.id }) { player ->
                val draft = statDrafts[player.id] ?: PlayerStatDraft()
                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("#${player.jerseyNumber} ${player.name} (${player.role.labelEn})", fontWeight = FontWeight.Bold)
                                val livePts = liveImpactMap[player] ?: 0.0
                                Text(
                                    text = "Impact: ${String.format(java.util.Locale.US, "%.2f", livePts)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = draft.isNotOut,
                                    onCheckedChange = { statDrafts[player.id] = draft.copy(isNotOut = it) }
                                )
                                Text("Not Out", style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = draft.runs,
                                onValueChange = { statDrafts[player.id] = draft.copy(runs = it.filter { c -> c.isDigit() }) },
                                label = { Text("Runs") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = draft.balls,
                                onValueChange = { statDrafts[player.id] = draft.copy(balls = it.filter { c -> c.isDigit() }) },
                                label = { Text("Balls") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = draft.fours,
                                onValueChange = { statDrafts[player.id] = draft.copy(fours = it.filter { c -> c.isDigit() }) },
                                label = { Text("4s") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = draft.sixes,
                                onValueChange = { statDrafts[player.id] = draft.copy(sixes = it.filter { c -> c.isDigit() }) },
                                label = { Text("6s") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = draft.oversBowled,
                                onValueChange = { statDrafts[player.id] = draft.copy(oversBowled = it); manualValidationError = null },
                                label = { Text("Bowl Ov") },
                                isError = !CricketStatsEngine.isValidOversInput(draft.oversBowled),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = draft.runsConceded,
                                onValueChange = { statDrafts[player.id] = draft.copy(runsConceded = it.filter { c -> c.isDigit() }) },
                                label = { Text("Runs Conc") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = draft.wickets,
                                onValueChange = { statDrafts[player.id] = draft.copy(wickets = it.filter { c -> c.isDigit() }) },
                                label = { Text("Wkts") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            if (matchPlayers.isNotEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Man of the Match (Auto Performance / Manual)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            if (autoTopPerformer != null) {
                                FilterChip(
                                    selected = autoSelectPom,
                                    onClick = { autoSelectPom = true },
                                    label = {
                                        Text("⚡ Auto Best: ${autoTopPerformer.first.name} (${String.format(java.util.Locale.US, "%.2f", autoTopPerformer.second)})")
                                    }
                                )
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                liveImpactRankings.take(12).forEach { (p, pts) ->
                                    FilterChip(
                                        selected = !autoSelectPom && manualPom?.id == p.id,
                                        onClick = {
                                            autoSelectPom = false
                                            manualPom = p
                                        },
                                        label = { Text("${p.name} (${String.format(java.util.Locale.US, "%.2f", pts)})") }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            val aRunsInt = aRuns.toIntOrNull() ?: 0
            val bRunsInt = bRuns.toIntOrNull() ?: 0
            if (aRunsInt == bRunsInt && manualTournament?.tieRule == TieRule.SUPER_OVER) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("সুপার ওভারে বিজয়ী", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = superOverWinnerId == 0L,
                                    onClick = { superOverWinnerId = 0L },
                                    label = { Text("ঠিক হয়নি") }
                                )
                                FilterChip(
                                    selected = superOverWinnerId == match.teamAId,
                                    onClick = { superOverWinnerId = match.teamAId },
                                    label = { Text(match.teamAName) }
                                )
                                FilterChip(
                                    selected = superOverWinnerId == match.teamBId,
                                    onClick = { superOverWinnerId = match.teamBId },
                                    label = { Text(match.teamBName) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = customResult,
                    onValueChange = { customResult = it },
                    label = { Text("Match Result Note (optional, auto-generated if empty)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                val combinedErr = manualValidationError
                    ?: liveErrA?.let { "${match.teamAName}: $it" }
                    ?: liveErrB?.let { "${match.teamBName}: $it" }
                if (combinedErr != null) {
                    Text(
                        text = combinedErr,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                Button(
                    onClick = {
                        if (!CricketStatsEngine.isValidOversInput(aOvers) || !CricketStatsEngine.isValidOversInput(bOvers)) {
                            manualValidationError = "সঠিক ওভার লিখুন (দশমিকের পর ০ থেকে ৫, যেমন ৭.৫)"
                            return@Button
                        }
                        val invalidBowler = matchPlayers.firstOrNull { p ->
                            val d = statDrafts[p.id] ?: PlayerStatDraft()
                            !CricketStatsEngine.isValidOversInput(d.oversBowled)
                        }
                        if (invalidBowler != null) {
                            manualValidationError = "${invalidBowler.name}: সঠিক ওভার লিখুন (দশমিকের পর ০ থেকে ৫, যেমন ২.৫)"
                            return@Button
                        }
                        val errA = CricketStatsEngine.validatePlayingSelection(selectedTeamAIds, playersPerSideLimit)
                        if (errA != null) {
                            manualValidationError = "${match.teamAName}: $errA"
                            return@Button
                        }
                        val errB = CricketStatsEngine.validatePlayingSelection(selectedTeamBIds, playersPerSideLimit)
                        if (errB != null) {
                            manualValidationError = "${match.teamBName}: $errB"
                            return@Button
                        }

                        val selectedPlayingSet = (selectedTeamAIds + selectedTeamBIds).toSet()
                        val playerStatsList = matchPlayers.mapNotNull { p ->
                            val d = statDrafts[p.id] ?: PlayerStatDraft()
                            val r = d.runs.toIntOrNull() ?: 0
                            val b = d.balls.toIntOrNull() ?: 0
                            val f4 = d.fours.toIntOrNull() ?: 0
                            val s6 = d.sixes.toIntOrNull() ?: 0
                            val bowlBalls = CricketStatsEngine.parseOversToBalls(d.oversBowled)
                            val conc = d.runsConceded.toIntOrNull() ?: 0
                            val wkts = d.wickets.toIntOrNull() ?: 0
                            val didBat = r > 0 || b > 0 || f4 > 0 || s6 > 0 || d.isNotOut
                            val didBowl = bowlBalls > 0 || conc > 0 || wkts > 0
                            if (!didBat && !didBowl && p.id !in selectedPlayingSet) return@mapNotNull null
                            PlayerMatchStatEntity(
                                tournamentId = match.tournamentId,
                                matchId = match.id,
                                teamId = p.teamId,
                                playerId = p.id,
                                playerName = p.name,
                                innings = if (p.teamId == battingFirstTeamId) 1 else 2,
                                didBat = didBat,
                                runsScored = r,
                                ballsFaced = b,
                                fours = f4,
                                sixes = s6,
                                isNotOut = d.isNotOut,
                                didBowl = didBowl,
                                ballsBowled = bowlBalls,
                                runsConceded = conc,
                                wicketsTaken = wkts
                            )
                        }

                        val chosenPomId = if (autoSelectPom) 0L else (effectivePom?.id ?: 0L)
                        val chosenPomName = if (autoSelectPom) "" else (effectivePom?.name ?: "")

                        viewModel.submitManualScore(
                            matchId = match.id,
                            teamARuns = aRuns.toIntOrNull() ?: 0,
                            teamAWickets = aWkts.toIntOrNull() ?: 0,
                            teamAOversText = aOvers,
                            teamAExtras = aExtras.toIntOrNull() ?: 0,
                            teamBRuns = bRuns.toIntOrNull() ?: 0,
                            teamBWickets = bWkts.toIntOrNull() ?: 0,
                            teamBOversText = bOvers,
                            teamBExtras = bExtras.toIntOrNull() ?: 0,
                            playerStats = playerStatsList,
                            pomId = chosenPomId,
                            pomName = chosenPomName,
                            customResultText = customResult,
                            battingFirstTeamId = battingFirstTeamId,
                            teamAPlayingIds = CricketStatsEngine.formatPlayingIds(selectedTeamAIds),
                            teamBPlayingIds = CricketStatsEngine.formatPlayingIds(selectedTeamBIds),
                            superOverWinnerTeamId = if (aRunsInt == bRunsInt) superOverWinnerId else 0L,
                            onError = { manualValidationError = it },
                            onSaved = onSaved
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(strings.save)
                }
            }
        }
    }
}
