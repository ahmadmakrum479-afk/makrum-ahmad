package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlayersScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val perms = uiState.permissionsFor(tournamentId)
    val teams = uiState.allTeams.filter { it.tournamentId == tournamentId }
    val players = uiState.allPlayers.filter { it.tournamentId == tournamentId }

    var selectedTeamFilter by remember { mutableStateOf<Long?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var inspectedPlayer by remember { mutableStateOf<PlayerEntity?>(null) }
    var editingStatsPlayer by remember { mutableStateOf<PlayerEntity?>(null) }

    val filtered = if (selectedTeamFilter == null) players else players.filter { it.teamId == selectedTeamFilter }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.players, subtitle = "${filtered.size} Players", onBack = onBack) },
        floatingActionButton = {
            if (perms.canEditTeams && teams.isNotEmpty()) {
                FloatingActionButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Rounded.PersonAdd, contentDescription = strings.addPlayer)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedTeamFilter == null,
                            onClick = { selectedTeamFilter = null },
                            label = { Text("All Teams") }
                        )
                    }
                    items(teams, key = { it.id }) { team ->
                        FilterChip(
                            selected = selectedTeamFilter == team.id,
                            onClick = { selectedTeamFilter = team.id },
                            label = { Text("${team.logoEmoji} ${team.shortCode}") }
                        )
                    }
                }
            }

            items(filtered, key = { it.id }) { player ->
                val team = teams.firstOrNull { it.id == player.teamId }
                val sr = CricketStatsEngine.calculateStrikeRate(player.runsScored, player.ballsFaced)
                val eco = CricketStatsEngine.calculateEconomyRate(player.runsConceded, player.ballsBowled)

                Card(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { inspectedPlayer = player }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "${player.photoEmoji} #${player.jerseyNumber} ${player.name}" + if (player.isCaptain) " (C)" else "",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${team?.name ?: ""} · ${player.role.labelEn}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "Runs: %d (SR %.1f) · Wkts: %d (Econ %.2f)",
                                    player.runsScored,
                                    sr,
                                    player.wicketsTaken,
                                    eco
                                ),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        Row {
                            if (perms.canScore || perms.canEditTeams) {
                                IconButton(onClick = { editingStatsPlayer = player }) {
                                    Icon(Icons.Rounded.Edit, contentDescription = "Edit Stats")
                                }
                            }
                            if (perms.canEditTeams) {
                                IconButton(onClick = { viewModel.deletePlayer(player) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = strings.delete)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    inspectedPlayer?.let { p ->
        val batAvg = CricketStatsEngine.calculateBattingAverage(p.runsScored, p.inningsBatted, p.notOuts)
        val sr = CricketStatsEngine.calculateStrikeRate(p.runsScored, p.ballsFaced)
        val eco = CricketStatsEngine.calculateEconomyRate(p.runsConceded, p.ballsBowled)
        val bowlAvg = CricketStatsEngine.calculateBowlingAverage(p.runsConceded, p.wicketsTaken)
        val best = if (p.bestBowlingWickets > 0) "${p.bestBowlingWickets}/${p.bestBowlingRuns}" else "-"

        AlertDialog(
            onDismissRequest = { inspectedPlayer = null },
            title = { Text("${p.photoEmoji} ${p.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${p.role.labelEn} · ${p.battingStyle} · ${p.bowlingStyle}")
                    Text("Matches: ${p.matchesPlayed} · Innings: ${p.inningsBatted} · Not Out: ${p.notOuts}")
                    Text(
                        String.format(
                            Locale.US,
                            "Batting: %d runs (%d balls) · HS %d · Avg %.2f · SR %.1f · 4s: %d · 6s: %d",
                            p.runsScored, p.ballsFaced, p.highestScore, batAvg, sr, p.fours, p.sixes
                        )
                    )
                    Text(
                        String.format(
                            Locale.US,
                            "Bowling: %s ov · %d runs · %d wkts · Econ %.2f · Avg %.2f · Best %s",
                            CricketStatsEngine.formatOvers(p.ballsBowled), p.runsConceded, p.wicketsTaken, eco, bowlAvg, best
                        )
                    )
                    Text("Player of Match Awards: ${p.playerOfMatchCount}")
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (perms.canScore || perms.canEditTeams) {
                        TextButton(onClick = {
                            editingStatsPlayer = p
                            inspectedPlayer = null
                        }) { Text("Edit Runs / Stats") }
                    }
                    TextButton(onClick = { inspectedPlayer = null }) { Text("Close") }
                }
            }
        )
    }

    editingStatsPlayer?.let { p ->
        var matchesText by remember(p.id) { mutableStateOf(p.matchesPlayed.toString()) }
        var runsText by remember(p.id) { mutableStateOf(p.runsScored.toString()) }
        var ballsText by remember(p.id) { mutableStateOf(p.ballsFaced.toString()) }
        var foursText by remember(p.id) { mutableStateOf(p.fours.toString()) }
        var sixesText by remember(p.id) { mutableStateOf(p.sixes.toString()) }
        var hsText by remember(p.id) { mutableStateOf(p.highestScore.toString()) }
        var wktsText by remember(p.id) { mutableStateOf(p.wicketsTaken.toString()) }
        var concText by remember(p.id) { mutableStateOf(p.runsConceded.toString()) }
        var oversText by remember(p.id) { mutableStateOf(CricketStatsEngine.formatOvers(p.ballsBowled)) }

        AlertDialog(
            onDismissRequest = { editingStatsPlayer = null },
            title = { Text("Edit Stats: ${p.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = matchesText,
                            onValueChange = { matchesText = it.filter { c -> c.isDigit() } },
                            label = { Text("Matches") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = runsText,
                            onValueChange = { runsText = it.filter { c -> c.isDigit() } },
                            label = { Text("Runs") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = ballsText,
                            onValueChange = { ballsText = it.filter { c -> c.isDigit() } },
                            label = { Text("Balls") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = foursText,
                            onValueChange = { foursText = it.filter { c -> c.isDigit() } },
                            label = { Text("4s") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = sixesText,
                            onValueChange = { sixesText = it.filter { c -> c.isDigit() } },
                            label = { Text("6s") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = hsText,
                            onValueChange = { hsText = it.filter { c -> c.isDigit() } },
                            label = { Text("Best") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = wktsText,
                            onValueChange = { wktsText = it.filter { c -> c.isDigit() } },
                            label = { Text("Wickets") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = concText,
                            onValueChange = { concText = it.filter { c -> c.isDigit() } },
                            label = { Text("Runs Conc") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = oversText,
                            onValueChange = { oversText = it },
                            label = { Text("Overs") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updatePlayerStatsDirect(
                        player = p,
                        matchesPlayed = matchesText.toIntOrNull() ?: p.matchesPlayed,
                        runsScored = runsText.toIntOrNull() ?: p.runsScored,
                        ballsFaced = ballsText.toIntOrNull() ?: p.ballsFaced,
                        fours = foursText.toIntOrNull() ?: p.fours,
                        sixes = sixesText.toIntOrNull() ?: p.sixes,
                        highestScore = hsText.toIntOrNull() ?: p.highestScore,
                        wicketsTaken = wktsText.toIntOrNull() ?: p.wicketsTaken,
                        runsConceded = concText.toIntOrNull() ?: p.runsConceded,
                        oversBowledText = oversText
                    )
                    editingStatsPlayer = null
                }) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { editingStatsPlayer = null }) { Text(strings.cancel) }
            }
        )
    }

    if (showAddDialog && teams.isNotEmpty()) {
        var name by remember { mutableStateOf("") }
        var jersey by remember { mutableStateOf("10") }
        var teamId by remember { mutableStateOf(selectedTeamFilter ?: teams.first().id) }
        var role by remember { mutableStateOf(PlayerRole.ALL_ROUNDER) }
        var batStyle by remember { mutableStateOf("Right-hand Bat") }
        var bowlStyle by remember { mutableStateOf("Right-arm Medium") }
        var isCaptain by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(strings.addPlayer) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Player Name") }, singleLine = true)
                    OutlinedTextField(
                        value = jersey,
                        onValueChange = { jersey = it.filter { c -> c.isDigit() } },
                        label = { Text("Jersey #") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    Text("Team", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        teams.forEach { t ->
                            FilterChip(
                                selected = teamId == t.id,
                                onClick = { teamId = t.id },
                                label = { Text(t.shortCode) }
                            )
                        }
                    }
                    Text("Role", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PlayerRole.entries.forEach { r ->
                            FilterChip(
                                selected = role == r,
                                onClick = { role = r },
                                label = { Text(r.labelEn) }
                            )
                        }
                    }
                    OutlinedTextField(value = batStyle, onValueChange = { batStyle = it }, label = { Text("Batting Style") }, singleLine = true)
                    OutlinedTextField(value = bowlStyle, onValueChange = { bowlStyle = it }, label = { Text("Bowling Style") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isCaptain, onCheckedChange = { isCaptain = it })
                        Text("Team Captain")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            viewModel.addPlayer(
                                tournamentId, teamId, name, jersey.toIntOrNull() ?: 1, role, batStyle, bowlStyle, "🧑", isCaptain
                            )
                            showAddDialog = false
                        }
                    }
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}
