package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.ui.theme.PitchEmeraldDark
import com.cricketmanager.app.viewmodel.CricketUiState
import java.util.Locale

@Composable
fun StatisticsScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isBn = strings.language == AppLanguage.BN
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId } ?: uiState.selectedTournament
    val tId = tournament?.id ?: tournamentId
    val players = uiState.allPlayers.filter { it.tournamentId == tId }
    val teams = uiState.allTeams.filter { it.tournamentId == tId }
    val tMatches = uiState.allMatches.filter { it.tournamentId == tId }
    val tMatchStats = uiState.allPlayerMatchStats.filter { it.tournamentId == tId }

    val mottByPlayerId = remember(players, tMatchStats, tMatches, tournament) {
        CricketStatsEngine.calculateTournamentMottBreakdownMap(players, tMatchStats, tMatches, tournament)
    }

    val tabs = if (isBn) {
        listOf("ম্যান অব দ্য টুর্নামেন্ট", "সর্বোচ্চ রান", "সর্বোচ্চ উইকেট", "স্ট্রাইক রেট", "সেরা বোলিং")
    } else {
        listOf("MOTT Ranking", "Top Runs", "Top Wickets", "Strike Rate", "Best Bowling")
    }
    var selectedTab by remember { mutableIntStateOf(0) }

    val ranked = when (selectedTab) {
        0 -> players.sortedByDescending { mottByPlayerId[it.id]?.totalScore ?: 0.0 }
        1 -> players.sortedByDescending { it.runsScored }
        2 -> players.sortedByDescending { it.wicketsTaken }
        3 -> players.filter { it.ballsFaced >= 6 }.ifEmpty { players }
            .sortedByDescending { CricketStatsEngine.calculateStrikeRate(it.runsScored, it.ballsFaced) }
        else -> players.sortedWith(
            compareByDescending<com.cricketmanager.app.data.local.PlayerEntity> { it.bestBowlingWickets }
                .thenBy { it.bestBowlingRuns }
                .thenByDescending { it.wicketsTaken }
        )
    }

    val mvpPlayer = players.maxByOrNull { mottByPlayerId[it.id]?.totalScore ?: 0.0 }
    val mvpBreakdown = mvpPlayer?.let { mottByPlayerId[it.id] }
    val topRunScorer = players.maxByOrNull { it.runsScored }
    val topWicketTaker = players.maxByOrNull { it.wicketsTaken }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.statistics, subtitle = tournament?.name, onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (mvpPlayer != null && mvpBreakdown != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = PitchEmeraldDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (isBn) "🏆 ম্যান অব দ্য টুর্নামেন্ট লিডার (গড়-ভিত্তিক)" else "🏆 Man of the Tournament Leader",
                                color = Color(0xFFFDE68A),
                                style = MaterialTheme.typography.labelMedium
                            )
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(mvpPlayer.name, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(String.format(Locale.US, "%.2f", mvpBreakdown.totalScore), color = Color(0xFFFDE68A), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            }
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "Bat: %.2f · Bowl: %.2f · (%dR, %dW, %d POM)",
                                    mvpBreakdown.battingScore,
                                    mvpBreakdown.bowlingScore,
                                    mvpPlayer.runsScored,
                                    mvpPlayer.wicketsTaken,
                                    mvpPlayer.playerOfMatchCount
                                ),
                                color = Color(0xFFD1FAE5),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            if (topRunScorer != null && topWicketTaker != null) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(if (isBn) "🏏 সর্বোচ্চ রান" else "🏏 Top Run Scorer", style = MaterialTheme.typography.labelSmall, color = PitchEmerald)
                                Text(topRunScorer.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("${topRunScorer.runsScored} Runs (HS ${topRunScorer.highestScore})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(if (isBn) "⚾ সর্বোচ্চ উইকেট" else "⚾ Top Wicket Taker", style = MaterialTheme.typography.labelSmall, color = PitchEmerald)
                                Text(topWicketTaker.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("${topWicketTaker.wicketsTaken} Wkts (Best ${topWicketTaker.bestBowlingWickets}/${topWicketTaker.bestBowlingRuns})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tabs.forEachIndexed { idx, label ->
                        item {
                            FilterChip(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            itemsIndexed(ranked, key = { _, p -> p.id }) { index, player ->
                val teamName = teams.firstOrNull { it.id == player.teamId }?.shortCode ?: ""
                val sr = CricketStatsEngine.calculateStrikeRate(player.runsScored, player.ballsFaced)
                val eco = CricketStatsEngine.calculateEconomyRate(player.runsConceded, player.ballsBowled)
                val bd = mottByPlayerId[player.id]
                val metric = when (selectedTab) {
                    0 -> String.format(Locale.US, "%.2f", bd?.totalScore ?: 0.0)
                    1 -> "${player.runsScored} R (${player.ballsFaced}B) · HS ${player.highestScore}"
                    2 -> "${player.wicketsTaken} W · Econ ${String.format(Locale.US, "%.2f", eco)}"
                    3 -> String.format(Locale.US, "SR %.1f (%dR/%dB)", sr, player.runsScored, player.ballsFaced)
                    else -> if (player.bestBowlingWickets > 0) "${player.bestBowlingWickets}/${player.bestBowlingRuns}" else "0/0"
                }
                val subLine = if (selectedTab == 0 && bd != null) {
                    String.format(Locale.US, "Bat: %.2f · Bowl: %.2f · %dR, %dW", bd.battingScore, bd.bowlingScore, player.runsScored, player.wicketsTaken)
                } else {
                    String.format(Locale.US, "%s · 4s: %d · 6s: %d · MOTT: %.2f", player.role.labelEn, player.fours, player.sixes, bd?.totalScore ?: 0.0)
                }

                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("#${index + 1} ${player.name} ($teamName)", fontWeight = FontWeight.Bold)
                            Text(
                                text = subLine,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(metric, fontWeight = FontWeight.Bold, color = PitchEmerald)
                    }
                }
            }

            if (selectedTab == 0) {
                val finMult = tournament?.mottFinalMultiplier ?: 1.5
                val wktShare = tournament?.mottBowlingWicketShare ?: 0.6
                val ecoShare = tournament?.mottBowlingEconomyShare ?: 0.4
                item {
                    Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (isBn) "ম্যান অব দ্য টুর্নামেন্টের সূত্র (গড়-ভিত্তিক)" else "Man of the Tournament Formula (Normalized)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isBn) {
                                    "• ব্যাটিং: প্রতি ইনিংসে (তার রান ÷ টুর্নামেন্টে ব্যাটারদের গড় রান), সব ইনিংসের যোগ।"
                                } else {
                                    "• Batting: Sum of (player runs / tournament avg batter runs) per innings."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (isBn) {
                                    "• বোলিং: প্রতি ম্যাচে (উইকেট ÷ গড় উইকেট) × $wktShare + min(গড় ইকোনমি ÷ তার ইকোনমি, ৩) × $ecoShare (ইকোনমি ডেটা না থাকলে উইকেটে ১০০% ওজন)।"
                                } else {
                                    "• Bowling: Per match (wkts / avg wkts) × $wktShare + min(avg econ / player econ, 3) × $ecoShare (100% weight on wickets when no economy data)."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (isBn) {
                                    "• ফাইনাল ম্যাচে ওজন ${finMult}× (টুর্নামেন্ট সেটিংসে বদলানো যাবে)। আলাদা MOTM +২০ বোনাস নেই।"
                                } else {
                                    "• Final match weight ${finMult}× (configurable in settings). No double-counted MOTM bonus."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
