package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.ui.theme.PitchEmeraldSoft
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@Composable
fun MyTournamentsScreen(
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onCreateTournament: () -> Unit,
    onOpenDetails: (Long) -> Unit
) {
    val strings = LocalAppStrings.current
    var query by remember { mutableStateOf("") }
    val filtered = uiState.tournaments.filter {
        query.isBlank() ||
            it.name.contains(query, ignoreCase = true) ||
            it.tournamentCode.contains(query, ignoreCase = true)
    }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.myTournaments) },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateTournament) {
                Icon(Icons.Rounded.Add, contentDescription = strings.createTournament)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    placeholder = { Text("Search name or code...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (filtered.isEmpty()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(strings.noTournamentsYet)
                            Button(onClick = onCreateTournament) {
                                Text(strings.createTournament)
                            }
                        }
                    }
                }
            }

            items(filtered, key = { it.id }) { t ->
                val isSelected = uiState.selectedTournament?.id == t.id
                val perms = uiState.permissionsFor(t.id)
                val teamCount = uiState.allTeams.count { it.tournamentId == t.id }
                val matchCount = uiState.allMatches.count { it.tournamentId == t.id }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) PitchEmeraldSoft.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.selectTournament(t.id)
                            onOpenDetails(t.id)
                        }
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${t.logoEmoji} ${t.name}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = perms.role.labelEn,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PitchEmerald,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Text(
                            text = "${t.format.labelEn} · ${t.pitchType.labelEn} · ${t.oversPerMatch} Overs",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Code: ${t.tournamentCode}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = PitchEmerald
                            )
                            Text(
                                text = "$teamCount Teams · $matchCount Matches",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }
        }
    }
}
