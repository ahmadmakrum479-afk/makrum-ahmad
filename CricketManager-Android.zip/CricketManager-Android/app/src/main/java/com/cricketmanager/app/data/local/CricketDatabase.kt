package com.cricketmanager.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.cricketmanager.app.domain.AuthSecurity
import com.cricketmanager.app.domain.BackupSerializer
import com.cricketmanager.app.domain.CricketStatsEngine

@Database(
    entities = [
        UserEntity::class,
        TournamentEntity::class,
        TeamEntity::class,
        PlayerEntity::class,
        MatchEntity::class,
        BallEventEntity::class,
        TournamentMemberEntity::class,
        AuditLogEntity::class,
        PlayerMatchStatEntity::class
    ],
    version = 9,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class CricketDatabase : RoomDatabase() {
    abstract fun cricketDao(): CricketDao

    companion object {
        @Volatile
        private var INSTANCE: CricketDatabase? = null

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tournaments ADD COLUMN playersPerSide INTEGER NOT NULL DEFAULT 11")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN squadSize INTEGER NOT NULL DEFAULT 15")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN allOutWickets INTEGER NOT NULL DEFAULT 10")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN maxOversPerBowler INTEGER NOT NULL DEFAULT 4")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN pointsWalkover INTEGER NOT NULL DEFAULT 2")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN tiebreakerOrder TEXT NOT NULL DEFAULT 'POINTS,WINS,NRR,H2H,NAME'")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN tieRule TEXT NOT NULL DEFAULT 'SHARE_POINTS'")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN matchesPerPair INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN playoffType TEXT NOT NULL DEFAULT 'SEMI_FINAL'")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN playoffTeamsCount INTEGER NOT NULL DEFAULT 4")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tournaments ADD COLUMN leaguePlayersPerSide INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN leagueSquadSize INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN leagueOvers INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN playoffPlayersPerSide INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN playoffSquadSize INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN playoffOvers INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN finalPlayersPerSide INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN finalSquadSize INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN finalOvers INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE matches ADD COLUMN playersPerSideSnapshot INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE matches ADD COLUMN squadSizeSnapshot INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE matches ADD COLUMN allOutWicketsSnapshot INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE matches ADD COLUMN maxOversPerBowlerSnapshot INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    """
                    UPDATE matches SET
                        playersPerSideSnapshot = COALESCE((SELECT playersPerSide FROM tournaments WHERE tournaments.id = matches.tournamentId), 11),
                        squadSizeSnapshot = COALESCE((SELECT squadSize FROM tournaments WHERE tournaments.id = matches.tournamentId), 15),
                        allOutWicketsSnapshot = COALESCE((SELECT allOutWickets FROM tournaments WHERE tournaments.id = matches.tournamentId), 10),
                        maxOversPerBowlerSnapshot = COALESCE((SELECT maxOversPerBowler FROM tournaments WHERE tournaments.id = matches.tournamentId), 4)
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tournaments ADD COLUMN mottBattingWeight REAL NOT NULL DEFAULT 1.0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN mottBowlingWeight REAL NOT NULL DEFAULT 1.0")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN mottBowlingWicketShare REAL NOT NULL DEFAULT 0.6")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN mottBowlingEconomyShare REAL NOT NULL DEFAULT 0.4")
                db.execSQL("ALTER TABLE tournaments ADD COLUMN mottFinalMultiplier REAL NOT NULL DEFAULT 1.5")
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE matches ADD COLUMN teamAPlayingIds TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE matches ADD COLUMN teamBPlayingIds TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val dateMap = mapOf(
                    10 to "2026-11-10",
                    15 to "2026-11-11",
                    9 to "2026-11-12",
                    7 to "2026-11-13",
                    6 to "2026-11-14",
                    12 to "2026-11-15",
                    13 to "2026-11-16",
                    5 to "2026-11-17",
                    8 to "2026-11-18",
                    1 to "2026-11-19",
                    2 to "2026-11-20",
                    3 to "2026-11-21",
                    4 to "2026-11-22",
                    14 to "2026-11-23",
                    11 to "2026-11-24"
                )
                val tCursor = db.query(
                    "SELECT id, oversPerMatch, pitchType, playersPerSide, maxOversPerBowler, tieRule FROM tournaments WHERE UPPER(tournamentCode) = 'CMCLNXFM' OR name = 'DARUL ULUM KALMA MADRASA'"
                )
                val tournamentRows = mutableListOf<List<Any>>()
                tCursor.use { c ->
                    while (c.moveToNext()) {
                        tournamentRows.add(
                            listOf(
                                c.getLong(0),
                                c.getInt(1),
                                c.getString(2) ?: "SHORT_PITCH",
                                c.getInt(3),
                                c.getInt(4),
                                c.getString(5) ?: "SHARE_POINTS"
                            )
                        )
                    }
                }
                for (row in tournamentRows) {
                    val tId = row[0] as Long
                    val overs = row[1] as Int
                    val pitchName = row[2] as String
                    val pitch = runCatching { PitchType.valueOf(pitchName) }.getOrDefault(PitchType.SHORT_PITCH)
                    val playersPerSide = row[3] as Int
                    val maxBowl = row[4] as Int
                    val tieRuleName = row[5] as String
                    val tieRule = runCatching { TieRule.valueOf(tieRuleName) }.getOrDefault(TieRule.SHARE_POINTS)
                    val dynamicSummary = CricketStatsEngine.formatRulesSummary(
                        oversPerMatch = overs,
                        pitchType = pitch,
                        playersPerSide = playersPerSide,
                        allOutWickets = 8,
                        maxOversPerBowler = maxBowl
                    )
                    db.execSQL(
                        """
                        UPDATE tournaments SET
                            allOutWickets = 8,
                            rulesSummary = ?,
                            leaguePlayersPerSide = 8,
                            leagueSquadSize = 12,
                            playoffPlayersPerSide = 8,
                            playoffSquadSize = 12,
                            finalPlayersPerSide = 11,
                            finalSquadSize = 15
                        WHERE id = ?
                        """.trimIndent(),
                        arrayOf(dynamicSummary, tId)
                    )

                    val mCursor = db.query(
                        """
                        SELECT id, matchNumber, stage, status, scheduledDate, scheduledTime,
                               teamAId, teamBId, teamAName, teamBName, teamARuns, teamAWickets,
                               teamBRuns, teamBWickets, battingFirstTeamId, winnerTeamId
                        FROM matches
                        WHERE tournamentId = ?
                        ORDER BY matchNumber ASC, id ASC
                        """.trimIndent(),
                        arrayOf(tId.toString())
                    )
                    data class MigMatch(
                        val id: Long,
                        val matchNumber: Int,
                        val stage: String,
                        val status: String,
                        val scheduledDate: String,
                        val scheduledTime: String,
                        val teamAId: Long,
                        val teamBId: Long,
                        val teamAName: String,
                        val teamBName: String,
                        val teamARuns: Int,
                        val teamAWickets: Int,
                        val teamBRuns: Int,
                        val teamBWickets: Int,
                        val battingFirstTeamId: Long,
                        val winnerTeamId: Long
                    )
                    val matches = mutableListOf<MigMatch>()
                    mCursor.use { mc ->
                        while (mc.moveToNext()) {
                            matches.add(
                                MigMatch(
                                    id = mc.getLong(0),
                                    matchNumber = mc.getInt(1),
                                    stage = mc.getString(2) ?: "LEAGUE",
                                    status = mc.getString(3) ?: "UPCOMING",
                                    scheduledDate = mc.getString(4) ?: "2026-11-10",
                                    scheduledTime = mc.getString(5) ?: "15:00",
                                    teamAId = mc.getLong(6),
                                    teamBId = mc.getLong(7),
                                    teamAName = mc.getString(8) ?: "",
                                    teamBName = mc.getString(9) ?: "",
                                    teamARuns = mc.getInt(10),
                                    teamAWickets = mc.getInt(11),
                                    teamBRuns = mc.getInt(12),
                                    teamBWickets = mc.getInt(13),
                                    battingFirstTeamId = mc.getLong(14),
                                    winnerTeamId = mc.getLong(15)
                                )
                            )
                        }
                    }

                    val leagueMatches = matches.filter { it.stage == "LEAGUE" || it.stage == "GROUP" }
                    val m1 = leagueMatches.firstOrNull { it.matchNumber == 1 }
                    val m10 = leagueMatches.firstOrNull { it.matchNumber == 10 }
                    val shouldRemapDates = m1 != null && m10 != null &&
                        m1.scheduledDate == "2026-11-10" && m1.status == "UPCOMING" && m10.scheduledDate != "2026-11-10"

                    if (shouldRemapDates) {
                        val remappedLeague = leagueMatches.map { mm ->
                            val newDate = dateMap[mm.matchNumber] ?: mm.scheduledDate
                            mm.copy(scheduledDate = newDate, scheduledTime = "15:00")
                        }.sortedWith(compareBy({ it.scheduledDate }, { it.scheduledTime }, { it.id }))
                        remappedLeague.forEachIndexed { idx, mm ->
                            db.execSQL(
                                "UPDATE matches SET scheduledDate = ?, scheduledTime = ?, matchNumber = ? WHERE id = ?",
                                arrayOf(mm.scheduledDate, mm.scheduledTime, idx + 1, mm.id)
                            )
                        }
                    }

                    for (mm in matches) {
                        if (mm.status == "UPCOMING") {
                            if (mm.stage == "FINAL") {
                                db.execSQL(
                                    "UPDATE matches SET playersPerSideSnapshot = 11, squadSizeSnapshot = 15, allOutWicketsSnapshot = 10 WHERE id = ?",
                                    arrayOf(mm.id)
                                )
                            } else {
                                db.execSQL(
                                    "UPDATE matches SET playersPerSideSnapshot = 8, squadSizeSnapshot = 12, allOutWicketsSnapshot = 8 WHERE id = ?",
                                    arrayOf(mm.id)
                                )
                            }
                        } else if (mm.status == "COMPLETED") {
                            val firstBat = if (mm.battingFirstTeamId == mm.teamBId) mm.teamBId else mm.teamAId
                            val (_, updatedSummary) = CricketStatsEngine.resolveMatchOutcome(
                                teamAId = mm.teamAId,
                                teamAName = mm.teamAName,
                                teamARuns = mm.teamARuns,
                                teamAWickets = mm.teamAWickets,
                                teamBId = mm.teamBId,
                                teamBName = mm.teamBName,
                                teamBRuns = mm.teamBRuns,
                                teamBWickets = mm.teamBWickets,
                                battingFirstTeamId = firstBat,
                                allOutWickets = 8,
                                isAbandoned = false,
                                tieRule = tieRule,
                                superOverWinnerTeamId = mm.winnerTeamId
                            )
                            db.execSQL(
                                "UPDATE matches SET resultSummary = ? WHERE id = ?",
                                arrayOf(updatedSummary, mm.id)
                            )
                        }
                    }
                }
            }
        }

        fun getInstance(context: Context): CricketDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CricketDatabase::class.java,
                    "cricket_manager.db"
                )
                    .addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
                    .build()
                    .also { INSTANCE = it }
            }
        }

        suspend fun seedDemoDataIfEmpty(db: CricketDatabase, context: Context? = null): Long? {
            val dao = db.cricketDao()
            if (dao.countTournaments() > 0) return dao.getFirstUser()?.id

            val adminId = dao.getUserByEmail("organizer@cricketmanager.app")?.id
                ?: dao.getFirstUser()?.id
                ?: dao.insertUser(
                    UserEntity(
                        fullName = "Tournament Organizer",
                        email = "organizer@cricketmanager.app",
                        passwordHash = AuthSecurity.hashPassword(AuthSecurity.generateCode("DEMO")),
                        organization = "Darul Ulum Kalma Madrasa"
                    )
                )

            if (context != null) {
                val assetJson = runCatching {
                    context.assets.open("default_tournament_seed.json").bufferedReader().use { it.readText() }
                }.getOrNull()
                if (!assetJson.isNullOrBlank()) {
                    val bundle = BackupSerializer.parseTournamentJson(assetJson, adminId)
                    val seededTId = dao.replaceTournamentBundle(
                        tournament = bundle.tournament.copy(ownerUserId = adminId, syncDirty = true),
                        teams = bundle.teams,
                        players = bundle.players,
                        matches = bundle.matches,
                        balls = bundle.balls,
                        members = bundle.members,
                        logs = bundle.logs,
                        playerMatchStats = bundle.playerMatchStats
                    )
                    dao.rebuildTournamentPlayerStats(seededTId)
                    dao.recalculateTournamentStandings(seededTId)
                    return adminId
                }
            }

            val tId = dao.insertTournament(
                TournamentEntity(
                    ownerUserId = adminId,
                    name = "Madrasa Premier Cup 2026",
                    logoEmoji = "🏆",
                    organizationName = "Central Cricket Association",
                    pitchType = PitchType.SHORT_PITCH,
                    scoringMode = ScoringMode.BALL_BY_BALL,
                    format = TournamentFormat.GROUP_KNOCKOUT,
                    oversPerMatch = 8,
                    playersPerSide = 8,
                    squadSize = 12,
                    allOutWickets = 7,
                    maxOversPerBowler = 2,
                    maxTeams = 4,
                    groupCount = 2,
                    rulesSummary = "8 overs per side · Short pitch · 8 players · 1 bouncer per over · Wide & No-ball = 1 run.",
                    pointsWin = 2,
                    pointsTie = 1,
                    pointsLoss = 0,
                    pointsAbandoned = 1,
                    pointsWalkover = 2,
                    tieRule = TieRule.SUPER_OVER,
                    matchesPerPair = 1,
                    playoffType = PlayoffType.SEMI_FINAL,
                    playoffTeamsCount = 4,
                    tournamentCode = "MPC26A",
                    editorCode = "ED8821",
                    viewerCode = "VW4092",
                    startDateLabel = "2026-05-10",
                    location = "City Madrasa Ground"
                )
            )

            dao.insertMember(
                TournamentMemberEntity(
                    tournamentId = tId,
                    userId = adminId,
                    userName = "Tournament Organizer",
                    userEmail = "organizer@cricketmanager.app",
                    role = UserRole.OWNER,
                    canEditTeams = true,
                    canEditSchedule = true,
                    canScore = true
                )
            )

            val teamIds = dao.insertTeams(
                listOf(
                    TeamEntity(
                        tournamentId = tId,
                        name = "Al-Noor Strikers",
                        shortCode = "ANS",
                        logoEmoji = "🦁",
                        captainName = "Tariq Hasan",
                        groupName = "Group A",
                        homeGround = "North Field"
                    ),
                    TeamEntity(
                        tournamentId = tId,
                        name = "Dhaka Challengers",
                        shortCode = "DHK",
                        logoEmoji = "🦅",
                        captainName = "Rafiq Islam",
                        groupName = "Group A",
                        homeGround = "Central Pitch"
                    ),
                    TeamEntity(
                        tournamentId = tId,
                        name = "Sylhet Royals",
                        shortCode = "SYL",
                        logoEmoji = "⚡",
                        captainName = "Nabil Ahmed",
                        groupName = "Group B",
                        homeGround = "Green Oval"
                    ),
                    TeamEntity(
                        tournamentId = tId,
                        name = "Chattogram Warriors",
                        shortCode = "CTG",
                        logoEmoji = "🔥",
                        captainName = "Farhan Karim",
                        groupName = "Group B",
                        homeGround = "Port Ground"
                    )
                )
            )

            val squadNames = listOf(
                listOf("Tariq Hasan", "Sajid Mia", "Arif Rahman", "Imran Ali", "Zayed Khan"),
                listOf("Rafiq Islam", "Mehedi Hasan", "Sumon Roy", "Tanvir Ahmed", "Rashedul"),
                listOf("Nabil Ahmed", "Kamrul Islam", "Shuvo Das", "Habibullah", "Mizanur"),
                listOf("Farhan Karim", "Asif Mahmud", "Rubel Mia", "Sabbir Hossain", "Naim Sheikh")
            )

            val roles = listOf(
                PlayerRole.BATSMAN,
                PlayerRole.WICKET_KEEPER,
                PlayerRole.ALL_ROUNDER,
                PlayerRole.BOWLER,
                PlayerRole.BOWLER
            )

            val allPlayers = mutableListOf<PlayerEntity>()
            teamIds.forEachIndexed { tIdx, teamId ->
                squadNames[tIdx].forEachIndexed { pIdx, pName ->
                    allPlayers.add(
                        PlayerEntity(
                            tournamentId = tId,
                            teamId = teamId,
                            name = pName,
                            jerseyNumber = (pIdx + 1) * 7,
                            role = roles[pIdx],
                            isCaptain = pIdx == 0
                        )
                    )
                }
            }
            dao.insertPlayers(allPlayers)

            val teamsInserted = dao.getTeamsByTournamentOnce(tId)
            val createdTournament = dao.getTournamentById(tId)
            val fixtures = CricketStatsEngine.generateFixtures(
                tournamentId = tId,
                teams = teamsInserted,
                format = TournamentFormat.ROUND_ROBIN,
                oversPerMatch = 8,
                scoringMode = ScoringMode.BALL_BY_BALL,
                venue = "City Madrasa Ground",
                startDateLabel = "2026-05-10",
                tournament = createdTournament
            )
            dao.insertMatches(fixtures)

            // Pre-score Match #1 so NRR, Scorecard, and Leaderboards immediately show rich live data
            val createdMatches = dao.getMatchesByTournamentOnce(tId)
            if (createdMatches.isNotEmpty()) {
                val m1 = createdMatches.first()
                val teamAPlayers = dao.getPlayersByTeamOnce(m1.teamAId)
                val teamBPlayers = dao.getPlayersByTeamOnce(m1.teamBId)
                if (teamAPlayers.size >= 4 && teamBPlayers.size >= 4) {
                    val pom = teamAPlayers[0]
                    val seedStats = listOf(
                        PlayerMatchStatEntity(
                            tournamentId = tId, matchId = m1.id, teamId = m1.teamAId,
                            playerId = teamAPlayers[0].id, playerName = teamAPlayers[0].name,
                            innings = 1, didBat = true, runsScored = 42, ballsFaced = 21, fours = 4, sixes = 2, isNotOut = true,
                            didBowl = true, ballsBowled = 12, runsConceded = 14, wicketsTaken = 1
                        ),
                        PlayerMatchStatEntity(
                            tournamentId = tId, matchId = m1.id, teamId = m1.teamAId,
                            playerId = teamAPlayers[1].id, playerName = teamAPlayers[1].name,
                            innings = 1, didBat = true, runsScored = 24, ballsFaced = 16, fours = 3, sixes = 0, isNotOut = false
                        ),
                        PlayerMatchStatEntity(
                            tournamentId = tId, matchId = m1.id, teamId = m1.teamAId,
                            playerId = teamAPlayers[3].id, playerName = teamAPlayers[3].name,
                            innings = 1, didBat = true, runsScored = 15, ballsFaced = 11, fours = 1, sixes = 1, isNotOut = false,
                            didBowl = true, ballsBowled = 12, runsConceded = 16, wicketsTaken = 3
                        ),
                        PlayerMatchStatEntity(
                            tournamentId = tId, matchId = m1.id, teamId = m1.teamBId,
                            playerId = teamBPlayers[0].id, playerName = teamBPlayers[0].name,
                            innings = 2, didBat = true, runsScored = 33, ballsFaced = 20, fours = 3, sixes = 1, isNotOut = false,
                            didBowl = true, ballsBowled = 12, runsConceded = 18, wicketsTaken = 2
                        ),
                        PlayerMatchStatEntity(
                            tournamentId = tId, matchId = m1.id, teamId = m1.teamBId,
                            playerId = teamBPlayers[1].id, playerName = teamBPlayers[1].name,
                            innings = 2, didBat = true, runsScored = 22, ballsFaced = 18, fours = 2, sixes = 0, isNotOut = true
                        ),
                        PlayerMatchStatEntity(
                            tournamentId = tId, matchId = m1.id, teamId = m1.teamBId,
                            playerId = teamBPlayers[3].id, playerName = teamBPlayers[3].name,
                            innings = 2, didBat = true, runsScored = 15, ballsFaced = 10, fours = 1, sixes = 1, isNotOut = false,
                            didBowl = true, ballsBowled = 12, runsConceded = 22, wicketsTaken = 2
                        )
                    )
                    dao.submitManualMatchScore(
                        matchId = m1.id,
                        teamARuns = 86,
                        teamAWickets = 4,
                        teamABalls = 48,
                        teamAExtras = 5,
                        teamBRuns = 74,
                        teamBWickets = 6,
                        teamBBalls = 48,
                        teamBExtras = 4,
                        playerStats = seedStats,
                        playerOfMatchId = pom.id,
                        playerOfMatchName = pom.name,
                        customResultText = "${m1.teamAName} won by 12 runs"
                    )
                }
            }

            dao.insertAuditLog(
                AuditLogEntity(
                    tournamentId = tId,
                    actorName = "Tournament Organizer",
                    actionTitle = "Tournament Initialized",
                    details = "Madrasa Premier Cup 2026 created with 4 teams and 6 fixtures."
                )
            )
            return adminId
        }
    }
}
