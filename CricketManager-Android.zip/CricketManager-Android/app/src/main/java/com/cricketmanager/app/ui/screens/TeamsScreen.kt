package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@Composable
fun TeamsScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onOpenPlayers: () -> Unit
) {
    val strings = LocalAppStrings.current
    val perms = uiState.permissionsFor(tournamentId)
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId }
    val tMatches = uiState.allMatches.filter { it.tournamentId == tournamentId }
    val teams = CricketStatsEngine.sortTeamsForPointsTable(
        uiState.allTeams.filter { it.tournamentId == tournamentId },
        tMatches,
        tournament?.tiebreakerOrder ?: "POINTS,WINS,NRR,H2H,NAME"
    )
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.teams, subtitle = "${teams.size} Teams", onBack = onBack) },
        floatingActionButton = {
            if (perms.canEditTeams) {
                FloatingActionButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = strings.addTeam)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!perms.canEditTeams) {
                item {
                    Text(
                        text = strings.viewerReadOnlyNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(teams, key = { it.id }) { team ->
                val playerCount = uiState.allPlayers.count { it.teamId == team.id }
                val nrr = CricketStatsEngine.calculateNetRunRate(
                    team.runsFor, team.ballsFaced, team.runsAgainst, team.ballsBowled
                )
                Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "${team.logoEmoji} ${team.name} (${team.shortCode})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${team.groupName} · Capt: ${team.captainName.ifBlank { "TBD" }} · $playerCount Players",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "P:${team.played}  W:${team.won}  L:${team.lost}  Pts:${team.points}  NRR:${CricketStatsEngine.formatNrr(nrr)}",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        Row {
                            OutlinedButton(onClick = onOpenPlayers) { Text(strings.players) }
                            if (perms.canEditTeams) {
                                IconButton(onClick = { viewModel.deleteTeam(team) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = strings.delete)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var shortCode by remember { mutableStateOf("") }
        var logoEmoji by remember { mutableStateOf("🏏") }
        var captain by remember { mutableStateOf("") }
        var groupName by remember { mutableStateOf("Group A") }
        var ground by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(strings.addTeam) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Team Name") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = shortCode,
                            onValueChange = { shortCode = it.uppercase().take(4) },
                            label = { Text("Code") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = logoEmoji,
                            onValueChange = { logoEmoji = it.take(2) },
                            label = { Text("Emoji") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(value = captain, onValueChange = { captain = it }, label = { Text("Captain Name") }, singleLine = true)
                    OutlinedTextField(value = groupName, onValueChange = { groupName = it }, label = { Text("Group") }, singleLine = true)
                    OutlinedTextField(value = ground, onValueChange = { ground = it }, label = { Text("Home Ground") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            viewModel.addTeam(
                                tournamentId,
                                name,
                                shortCode.ifBlank { name.take(3).uppercase() },
                                logoEmoji,
                                captain,
                                groupName,
                                ground
                            )
                            showAddDialog = false
                        }
                    }
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}
