package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.theme.BoundaryCrimson
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.ui.theme.PitchEmeraldDark
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@Composable
fun HomeDashboardScreen(
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onOpenCreateTournament: () -> Unit,
    onOpenTournaments: () -> Unit,
    onOpenTournamentDetails: (Long) -> Unit,
    onOpenLiveScoring: (Long) -> Unit,
    onOpenManualScoring: (Long) -> Unit,
    onOpenScorecard: (Long) -> Unit,
    onOpenSchedule: (Long) -> Unit,
    onOpenPoints: (Long) -> Unit
) {
    val strings = LocalAppStrings.current
    val activeTournament = uiState.selectedTournament
    var joinCode by remember { mutableStateOf("") }
    val permissions = uiState.currentPermissions

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.appTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${uiState.activeUser?.fullName ?: "Organizer"} · ${uiState.tournaments.size} ${strings.myTournaments}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = { viewModel.setLanguage(if (uiState.languageCode == "BN") "EN" else "BN") }
                ) {
                    Icon(Icons.Rounded.Translate, contentDescription = strings.languageToggle)
                }
                IconButton(onClick = { viewModel.syncNow() }) {
                    Icon(Icons.Rounded.Sync, contentDescription = strings.syncNow)
                }
            }
        }

        // Sync / Offline Status Banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (uiState.isFirebaseConfigured) Color(0xFFD1FAE5) else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (uiState.isFirebaseConfigured) Icons.Rounded.CloudDone else Icons.Rounded.CloudOff,
                        contentDescription = null,
                        tint = if (uiState.isFirebaseConfigured) PitchEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (uiState.isFirebaseConfigured) strings.syncFirebaseActive else strings.syncFirebaseMissing,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Active Tournament Hero Card
        item {
            if (activeTournament != null) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = PitchEmeraldDark),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenTournamentDetails(activeTournament.id) }
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${activeTournament.logoEmoji} ${activeTournament.name}",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0x33FFFFFF)
                            ) {
                                Text(
                                    text = permissions.role.labelEn,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = "${activeTournament.pitchType.labelEn} · ${activeTournament.oversPerMatch} Overs · ${activeTournament.format.labelEn}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD1FAE5)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Code: ${activeTournament.tournamentCode}",
                                color = Color(0xFFFDE68A),
                                style = MaterialTheme.typography.labelMedium
                            )
                            Text(
                                text = "${uiState.selectedTeams.size} Teams · ${uiState.selectedMatches.size} Matches",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onOpenTournamentDetails(activeTournament.id) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(strings.tournamentDetails)
                            }
                            OutlinedButton(
                                onClick = { onOpenSchedule(activeTournament.id) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(strings.schedule, color = Color.White)
                            }
                        }
                    }
                }
            } else {
                Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(strings.noTournamentsYet, style = MaterialTheme.typography.bodyLarge)
                        Button(onClick = onOpenCreateTournament) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.createTournament)
                        }
                    }
                }
            }
        }

        // Quick Actions + Join by Code
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenCreateTournament,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.createTournament)
                }
                OutlinedButton(
                    onClick = onOpenTournaments,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Icon(Icons.Rounded.EmojiEvents, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.myTournaments)
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.Key, contentDescription = null, tint = PitchEmerald)
                        Text(strings.joinByCode, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = joinCode,
                            onValueChange = { joinCode = it.uppercase() },
                            placeholder = { Text(strings.joinCodePlaceholder) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                viewModel.joinTournamentByCode(joinCode) { id ->
                                    joinCode = ""
                                    onOpenTournamentDetails(id)
                                }
                            },
                            modifier = Modifier.height(52.dp)
                        ) {
                            Text(strings.joinBtn)
                        }
                    }
                }
            }
        }

        // Recent & Live Matches
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${strings.liveMatches} & ${strings.schedule}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (activeTournament != null) {
                    OutlinedButton(onClick = { onOpenPoints(activeTournament.id) }) {
                        Text(strings.pointsTable)
                    }
                }
            }
        }

        items(uiState.selectedMatches.take(6), key = { it.id }) { match ->
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenScorecard(match.id) }
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Match #${match.matchNumber} · ${match.stage.labelEn}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = match.status.labelEn,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (match.status == MatchStatus.LIVE) BoundaryCrimson else PitchEmerald
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(match.teamAName, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${match.teamARuns}/${match.teamAWickets} (${CricketStatsEngine.formatOvers(match.teamABalls)})",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(match.teamBName, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${match.teamBRuns}/${match.teamBWickets} (${CricketStatsEngine.formatOvers(match.teamBBalls)})",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = match.resultSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (permissions.canScore && match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED) {
                            Button(
                                onClick = {
                                    if (match.scoringMode == ScoringMode.BALL_BY_BALL) {
                                        onOpenLiveScoring(match.id)
                                    } else {
                                        onOpenManualScoring(match.id)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text(if (match.scoringMode == ScoringMode.BALL_BY_BALL) strings.liveScoring else strings.manualScoring)
                            }
                        }
                        OutlinedButton(
                            onClick = { onOpenScorecard(match.id) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(strings.scorecard)
                        }
                    }
                }
            }
        }
    }
}
