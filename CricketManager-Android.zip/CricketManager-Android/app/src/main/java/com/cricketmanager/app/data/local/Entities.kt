package com.cricketmanager.app.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val email: String,
    val passwordHash: String,
    val organization: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "tournaments",
    indices = [Index(value = ["tournamentCode"], unique = true)]
)
data class TournamentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: Long,
    val name: String,
    val logoEmoji: String = "🏆",
    val organizationName: String = "",
    val pitchType: PitchType = PitchType.FULL_PITCH,
    val scoringMode: ScoringMode = ScoringMode.BALL_BY_BALL,
    val format: TournamentFormat = TournamentFormat.LEAGUE,
    val oversPerMatch: Int = 20,
    val playersPerSide: Int = 11,
    val squadSize: Int = 15,
    val allOutWickets: Int = 10,
    val maxOversPerBowler: Int = 4,
    val maxTeams: Int = 8,
    val groupCount: Int = 2,
    val rulesSummary: String = "Standard ICC rules. Wide/No-ball = 1 extra run.",
    val pointsWin: Int = 2,
    val pointsTie: Int = 1,
    val pointsLoss: Int = 0,
    val pointsAbandoned: Int = 1,
    val pointsWalkover: Int = 2,
    val tiebreakerOrder: String = "POINTS,WINS,NRR,H2H,NAME",
    val tieRule: TieRule = TieRule.SHARE_POINTS,
    val matchesPerPair: Int = 1,
    val playoffType: PlayoffType = PlayoffType.SEMI_FINAL,
    val playoffTeamsCount: Int = 4,
    val leaguePlayersPerSide: Int = 0,
    val leagueSquadSize: Int = 0,
    val leagueOvers: Int = 0,
    val playoffPlayersPerSide: Int = 0,
    val playoffSquadSize: Int = 0,
    val playoffOvers: Int = 0,
    val finalPlayersPerSide: Int = 0,
    val finalSquadSize: Int = 0,
    val finalOvers: Int = 0,
    val mottBattingWeight: Double = 1.0,
    val mottBowlingWeight: Double = 1.0,
    val mottBowlingWicketShare: Double = 0.6,
    val mottBowlingEconomyShare: Double = 0.4,
    val mottFinalMultiplier: Double = 1.5,
    val tournamentCode: String,
    val editorCode: String,
    val viewerCode: String,
    val startDateLabel: String = "2026-05-01",
    val location: String = "Central Ground",
    val isArchived: Boolean = false,
    val syncDirty: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "teams",
    foreignKeys = [
        ForeignKey(
            entity = TournamentEntity::class,
            parentColumns = ["id"],
            childColumns = ["tournamentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["tournamentId"])]
)
data class TeamEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val name: String,
    val shortCode: String,
    val logoEmoji: String = "🏏",
    val captainName: String = "",
    val groupName: String = "Group A",
    val homeGround: String = "",
    val played: Int = 0,
    val won: Int = 0,
    val lost: Int = 0,
    val tiedOrAbandoned: Int = 0,
    val points: Int = 0,
    val runsFor: Int = 0,
    val ballsFaced: Int = 0,
    val runsAgainst: Int = 0,
    val ballsBowled: Int = 0
)

@Entity(
    tableName = "players",
    foreignKeys = [
        ForeignKey(
            entity = TournamentEntity::class,
            parentColumns = ["id"],
            childColumns = ["tournamentId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TeamEntity::class,
            parentColumns = ["id"],
            childColumns = ["teamId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["tournamentId"]), Index(value = ["teamId"])]
)
data class PlayerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val teamId: Long,
    val name: String,
    val jerseyNumber: Int = 1,
    val role: PlayerRole = PlayerRole.ALL_ROUNDER,
    val battingStyle: String = "Right-hand Bat",
    val bowlingStyle: String = "Right-arm Medium",
    val photoEmoji: String = "🧑",
    val isCaptain: Boolean = false,
    val matchesPlayed: Int = 0,
    val inningsBatted: Int = 0,
    val runsScored: Int = 0,
    val ballsFaced: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val notOuts: Int = 0,
    val highestScore: Int = 0,
    val ballsBowled: Int = 0,
    val runsConceded: Int = 0,
    val wicketsTaken: Int = 0,
    val bestBowlingWickets: Int = 0,
    val bestBowlingRuns: Int = 0,
    val playerOfMatchCount: Int = 0
)

@Entity(
    tableName = "matches",
    foreignKeys = [
        ForeignKey(
            entity = TournamentEntity::class,
            parentColumns = ["id"],
            childColumns = ["tournamentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["tournamentId"])]
)
data class MatchEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val matchNumber: Int = 1,
    val stage: MatchStage = MatchStage.LEAGUE,
    val groupName: String = "Group A",
    val teamAId: Long,
    val teamBId: Long,
    val teamAName: String,
    val teamBName: String,
    val venue: String = "Main Pitch",
    val scheduledDate: String = "Today",
    val scheduledTime: String = "15:00",
    val oversLimit: Int = 10,
    val playersPerSideSnapshot: Int = 0,
    val squadSizeSnapshot: Int = 0,
    val allOutWicketsSnapshot: Int = 0,
    val maxOversPerBowlerSnapshot: Int = 0,
    val scoringMode: ScoringMode = ScoringMode.BALL_BY_BALL,
    val status: MatchStatus = MatchStatus.UPCOMING,
    val currentInnings: Int = 1,
    val battingFirstTeamId: Long = 0,
    val teamARuns: Int = 0,
    val teamAWickets: Int = 0,
    val teamABalls: Int = 0,
    val teamAExtras: Int = 0,
    val teamBRuns: Int = 0,
    val teamBWickets: Int = 0,
    val teamBBalls: Int = 0,
    val teamBExtras: Int = 0,
    val activeStrikerId: Long = 0,
    val activeNonStrikerId: Long = 0,
    val activeBowlerId: Long = 0,
    val teamAPlayingIds: String = "",
    val teamBPlayingIds: String = "",
    val winnerTeamId: Long = 0,
    val playerOfMatchId: Long = 0,
    val playerOfMatchName: String = "",
    val resultSummary: String = "Match scheduled",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "ball_events",
    foreignKeys = [
        ForeignKey(
            entity = MatchEntity::class,
            parentColumns = ["id"],
            childColumns = ["matchId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["matchId"])]
)
data class BallEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val matchId: Long,
    val innings: Int,
    val sequenceNumber: Int,
    val overNumber: Int,
    val ballInOver: Int,
    val strikerId: Long,
    val nonStrikerId: Long,
    val bowlerId: Long,
    val runsOffBat: Int = 0,
    val extraRuns: Int = 0,
    val extraType: ExtraType = ExtraType.NONE,
    val isWicket: Boolean = false,
    val wicketType: WicketType = WicketType.NONE,
    val dismissedPlayerId: Long = 0,
    val isBoundaryFour: Boolean = false,
    val isBoundarySix: Boolean = false,
    val summaryLabel: String = "0",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "tournament_members",
    foreignKeys = [
        ForeignKey(
            entity = TournamentEntity::class,
            parentColumns = ["id"],
            childColumns = ["tournamentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["tournamentId"]), Index(value = ["userId"])]
)
data class TournamentMemberEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val userId: Long,
    val userName: String,
    val userEmail: String,
    val role: UserRole = UserRole.VIEWER,
    val canEditTeams: Boolean = false,
    val canEditSchedule: Boolean = false,
    val canScore: Boolean = false,
    val joinedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "audit_logs",
    foreignKeys = [
        ForeignKey(
            entity = TournamentEntity::class,
            parentColumns = ["id"],
            childColumns = ["tournamentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["tournamentId"])]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val actorName: String,
    val actionTitle: String,
    val details: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "player_match_stats",
    foreignKeys = [
        ForeignKey(
            entity = MatchEntity::class,
            parentColumns = ["id"],
            childColumns = ["matchId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["matchId"]), Index(value = ["playerId"])]
)
data class PlayerMatchStatEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val matchId: Long,
    val teamId: Long,
    val playerId: Long,
    val playerName: String,
    val innings: Int,
    val didBat: Boolean = false,
    val runsScored: Int = 0,
    val ballsFaced: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val isNotOut: Boolean = false,
    val didBowl: Boolean = false,
    val ballsBowled: Int = 0,
    val runsConceded: Int = 0,
    val wicketsTaken: Int = 0
)
