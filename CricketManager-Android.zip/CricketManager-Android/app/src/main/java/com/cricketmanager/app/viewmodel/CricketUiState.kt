package com.cricketmanager.app.viewmodel

import com.cricketmanager.app.data.local.AuditLogEntity
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentMemberEntity
import com.cricketmanager.app.data.local.UserEntity
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.domain.CricketStatsEngine

data class TournamentPermissions(
    val role: UserRole = UserRole.VIEWER,
    val canManageRoles: Boolean = false,
    val canEditTeams: Boolean = false,
    val canEditSchedule: Boolean = false,
    val canScore: Boolean = false
)

data class CricketUiState(
    val isReady: Boolean = false,
    val activeUser: UserEntity? = null,
    val languageCode: String = "BN",
    val autoSync: Boolean = true,
    val lastSyncAt: Long = 0L,
    val isFirebaseConfigured: Boolean = false,
    val tournaments: List<TournamentEntity> = emptyList(),
    val selectedTournamentId: Long = 0L,
    val allTeams: List<TeamEntity> = emptyList(),
    val allPlayers: List<PlayerEntity> = emptyList(),
    val allMatches: List<MatchEntity> = emptyList(),
    val allBallEvents: List<BallEventEntity> = emptyList(),
    val allPlayerMatchStats: List<PlayerMatchStatEntity> = emptyList(),
    val allMembers: List<TournamentMemberEntity> = emptyList(),
    val allAuditLogs: List<AuditLogEntity> = emptyList(),
    val statusMessage: String? = null,
    val exportedBackupJson: String? = null
) {
    val selectedTournament: TournamentEntity?
        get() = tournaments.firstOrNull { it.id == selectedTournamentId } ?: tournaments.firstOrNull()

    val selectedTeams: List<TeamEntity>
        get() = selectedTournament?.let { t ->
            allTeams.filter { it.tournamentId == t.id }
        } ?: emptyList()

    val selectedStandings: List<TeamEntity>
        get() = CricketStatsEngine.sortTeamsForPointsTable(selectedTeams)

    val selectedPlayers: List<PlayerEntity>
        get() = selectedTournament?.let { t ->
            allPlayers.filter { it.tournamentId == t.id }
        } ?: emptyList()

    val selectedMatches: List<MatchEntity>
        get() = selectedTournament?.let { t ->
            allMatches.filter { it.tournamentId == t.id }
        } ?: emptyList()

    val selectedMembers: List<TournamentMemberEntity>
        get() = selectedTournament?.let { t ->
            allMembers.filter { it.tournamentId == t.id }
        } ?: emptyList()

    val selectedAuditLogs: List<AuditLogEntity>
        get() = selectedTournament?.let { t ->
            allAuditLogs.filter { it.tournamentId == t.id }
        } ?: emptyList()

    fun permissionsFor(tournamentId: Long): TournamentPermissions {
        val user = activeUser ?: return TournamentPermissions()
        val tournament = tournaments.firstOrNull { it.id == tournamentId }
        if (tournament != null && tournament.ownerUserId == user.id) {
            return TournamentPermissions(
                role = UserRole.OWNER,
                canManageRoles = true,
                canEditTeams = true,
                canEditSchedule = true,
                canScore = true
            )
        }
        val member = allMembers.firstOrNull { it.tournamentId == tournamentId && it.userId == user.id }
            ?: return TournamentPermissions()
        val isOwnerOrAdmin = member.role == UserRole.OWNER || member.role == UserRole.ADMIN
        return TournamentPermissions(
            role = member.role,
            canManageRoles = isOwnerOrAdmin,
            canEditTeams = isOwnerOrAdmin || member.canEditTeams,
            canEditSchedule = isOwnerOrAdmin || member.canEditSchedule,
            canScore = isOwnerOrAdmin || member.canScore || member.role == UserRole.EDITOR
        )
    }

    val currentPermissions: TournamentPermissions
        get() = selectedTournament?.let { permissionsFor(it.id) } ?: TournamentPermissions()
}
