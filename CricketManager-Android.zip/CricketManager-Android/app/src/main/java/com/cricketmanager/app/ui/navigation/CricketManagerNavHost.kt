package com.cricketmanager.app.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.screens.AuthScreen
import com.cricketmanager.app.ui.screens.CreateTournamentScreen
import com.cricketmanager.app.ui.screens.HomeDashboardScreen
import com.cricketmanager.app.ui.screens.LiveScoringScreen
import com.cricketmanager.app.ui.screens.ManualScoringScreen
import com.cricketmanager.app.ui.screens.MatchScheduleScreen
import com.cricketmanager.app.ui.screens.MyTournamentsScreen
import com.cricketmanager.app.ui.screens.PlayersScreen
import com.cricketmanager.app.ui.screens.PointsTableScreen
import com.cricketmanager.app.ui.screens.ScorecardScreen
import com.cricketmanager.app.ui.screens.SettingsScreen
import com.cricketmanager.app.ui.screens.SplashScreen
import com.cricketmanager.app.ui.screens.StatisticsScreen
import com.cricketmanager.app.ui.screens.TeamsScreen
import com.cricketmanager.app.ui.screens.TournamentDetailsScreen
import com.cricketmanager.app.ui.screens.UserPermissionsScreen
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

object Routes {
    const val SPLASH = "splash"
    const val AUTH = "auth"
    const val HOME = "home"
    const val CREATE_TOURNAMENT = "create_tournament"
    const val MY_TOURNAMENTS = "my_tournaments"
    const val TOURNAMENT_DETAILS = "tournament_details/{tournamentId}"
    const val TEAMS = "teams/{tournamentId}"
    const val PLAYERS = "players/{tournamentId}"
    const val SCHEDULE = "schedule/{tournamentId}"
    const val LIVE_SCORING = "live_scoring/{matchId}"
    const val MANUAL_SCORING = "manual_scoring/{matchId}"
    const val SCORECARD = "scorecard/{matchId}"
    const val POINTS_TABLE = "points_table/{tournamentId}"
    const val STATISTICS = "statistics/{tournamentId}"
    const val PERMISSIONS = "permissions/{tournamentId}"
    const val SETTINGS = "settings"

    fun tournamentDetails(id: Long) = "tournament_details/$id"
    fun teams(id: Long) = "teams/$id"
    fun players(id: Long) = "players/$id"
    fun schedule(id: Long) = "schedule/$id"
    fun liveScoring(matchId: Long) = "live_scoring/$matchId"
    fun manualScoring(matchId: Long) = "manual_scoring/$matchId"
    fun scorecard(matchId: Long) = "scorecard/$matchId"
    fun pointsTable(id: Long) = "points_table/$id"
    fun statistics(id: Long) = "statistics/$id"
    fun permissions(id: Long) = "permissions/$id"
}

@Composable
fun CricketManagerNavHost(
    uiState: CricketUiState,
    viewModel: CricketViewModel
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val strings = LocalAppStrings.current
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    val topLevelRoutes = setOf(
        Routes.HOME,
        Routes.MY_TOURNAMENTS,
        Routes.POINTS_TABLE,
        Routes.STATISTICS,
        Routes.SETTINGS
    )

    val activeTournamentId = uiState.selectedTournament?.id ?: 0L

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (currentRoute in topLevelRoutes) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute == Routes.HOME,
                        onClick = {
                            navController.navigate(Routes.HOME) {
                                popUpTo(Routes.HOME) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(Icons.Rounded.Home, contentDescription = strings.dashboard) },
                        label = { Text(strings.dashboard, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.MY_TOURNAMENTS,
                        onClick = {
                            navController.navigate(Routes.MY_TOURNAMENTS) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(Icons.Rounded.EmojiEvents, contentDescription = strings.myTournaments) },
                        label = { Text(strings.myTournaments, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.POINTS_TABLE,
                        onClick = {
                            if (activeTournamentId > 0L) {
                                navController.navigate(Routes.pointsTable(activeTournamentId)) {
                                    launchSingleTop = true
                                }
                            } else {
                                navController.navigate(Routes.MY_TOURNAMENTS)
                            }
                        },
                        icon = { Icon(Icons.Rounded.Leaderboard, contentDescription = strings.pointsTable) },
                        label = { Text(strings.pointsTable, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.STATISTICS,
                        onClick = {
                            if (activeTournamentId > 0L) {
                                navController.navigate(Routes.statistics(activeTournamentId)) {
                                    launchSingleTop = true
                                }
                            } else {
                                navController.navigate(Routes.MY_TOURNAMENTS)
                            }
                        },
                        icon = { Icon(Icons.Rounded.BarChart, contentDescription = strings.statistics) },
                        label = { Text(strings.statistics, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Routes.SETTINGS,
                        onClick = {
                            navController.navigate(Routes.SETTINGS) {
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(Icons.Rounded.Settings, contentDescription = strings.settings) },
                        label = { Text(strings.settings, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = Routes.SPLASH
            ) {
                composable(Routes.SPLASH) {
                    SplashScreen(
                        isReady = uiState.isReady,
                        hasActiveUser = uiState.activeUser != null,
                        onNavigateHome = {
                            navController.navigate(Routes.HOME) {
                                popUpTo(Routes.SPLASH) { inclusive = true }
                            }
                        },
                        onNavigateAuth = {
                            navController.navigate(Routes.AUTH) {
                                popUpTo(Routes.SPLASH) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Routes.AUTH) {
                    AuthScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onAuthenticated = {
                            navController.navigate(Routes.HOME) {
                                popUpTo(Routes.AUTH) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Routes.HOME) {
                    HomeDashboardScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onOpenCreateTournament = { navController.navigate(Routes.CREATE_TOURNAMENT) },
                        onOpenTournaments = { navController.navigate(Routes.MY_TOURNAMENTS) },
                        onOpenTournamentDetails = { id -> navController.navigate(Routes.tournamentDetails(id)) },
                        onOpenLiveScoring = { matchId -> navController.navigate(Routes.liveScoring(matchId)) },
                        onOpenManualScoring = { matchId -> navController.navigate(Routes.manualScoring(matchId)) },
                        onOpenScorecard = { matchId -> navController.navigate(Routes.scorecard(matchId)) },
                        onOpenSchedule = { id -> navController.navigate(Routes.schedule(id)) },
                        onOpenPoints = { id -> navController.navigate(Routes.pointsTable(id)) }
                    )
                }

                composable(Routes.CREATE_TOURNAMENT) {
                    CreateTournamentScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onCreated = { tId ->
                            navController.navigate(Routes.tournamentDetails(tId)) {
                                popUpTo(Routes.CREATE_TOURNAMENT) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Routes.MY_TOURNAMENTS) {
                    MyTournamentsScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onCreateTournament = { navController.navigate(Routes.CREATE_TOURNAMENT) },
                        onOpenDetails = { tId -> navController.navigate(Routes.tournamentDetails(tId)) }
                    )
                }

                composable(
                    route = Routes.TOURNAMENT_DETAILS,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    TournamentDetailsScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onOpenTeams = { navController.navigate(Routes.teams(tId)) },
                        onOpenPlayers = { navController.navigate(Routes.players(tId)) },
                        onOpenSchedule = { navController.navigate(Routes.schedule(tId)) },
                        onOpenPoints = { navController.navigate(Routes.pointsTable(tId)) },
                        onOpenStats = { navController.navigate(Routes.statistics(tId)) },
                        onOpenPermissions = { navController.navigate(Routes.permissions(tId)) }
                    )
                }

                composable(
                    route = Routes.TEAMS,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    TeamsScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onOpenPlayers = { navController.navigate(Routes.players(tId)) }
                    )
                }

                composable(
                    route = Routes.PLAYERS,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    PlayersScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = Routes.SCHEDULE,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    MatchScheduleScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onOpenLiveScoring = { mId -> navController.navigate(Routes.liveScoring(mId)) },
                        onOpenManualScoring = { mId -> navController.navigate(Routes.manualScoring(mId)) },
                        onOpenScorecard = { mId -> navController.navigate(Routes.scorecard(mId)) }
                    )
                }

                composable(
                    route = Routes.LIVE_SCORING,
                    arguments = listOf(navArgument("matchId") { type = NavType.LongType })
                ) { entry ->
                    val matchId = entry.arguments?.getLong("matchId") ?: 0L
                    LiveScoringScreen(
                        matchId = matchId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onOpenScorecard = { navController.navigate(Routes.scorecard(matchId)) },
                        onOpenManualScoring = { navController.navigate(Routes.manualScoring(matchId)) }
                    )
                }

                composable(
                    route = Routes.MANUAL_SCORING,
                    arguments = listOf(navArgument("matchId") { type = NavType.LongType })
                ) { entry ->
                    val matchId = entry.arguments?.getLong("matchId") ?: 0L
                    ManualScoringScreen(
                        matchId = matchId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onSaved = {
                            navController.navigate(Routes.scorecard(matchId)) {
                                popUpTo(Routes.MANUAL_SCORING) { inclusive = true }
                            }
                        }
                    )
                }

                composable(
                    route = Routes.SCORECARD,
                    arguments = listOf(navArgument("matchId") { type = NavType.LongType })
                ) { entry ->
                    val matchId = entry.arguments?.getLong("matchId") ?: 0L
                    ScorecardScreen(
                        matchId = matchId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onOpenLiveScoring = { navController.navigate(Routes.liveScoring(matchId)) },
                        onOpenManualScoring = { navController.navigate(Routes.manualScoring(matchId)) }
                    )
                }

                composable(
                    route = Routes.POINTS_TABLE,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    PointsTableScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = Routes.STATISTICS,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    StatisticsScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = Routes.PERMISSIONS,
                    arguments = listOf(navArgument("tournamentId") { type = NavType.LongType })
                ) { entry ->
                    val tId = entry.arguments?.getLong("tournamentId") ?: activeTournamentId
                    UserPermissionsScreen(
                        tournamentId = tId,
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onSignedOut = {
                            navController.navigate(Routes.AUTH) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenTopBar(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            }
        },
        title = {
            androidx.compose.foundation.layout.Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    )
}
