package com.cricketmanager.app.domain

import com.cricketmanager.app.data.local.AuditLogEntity
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.PlayoffType
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.TournamentMemberEntity
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.data.local.WicketType
import org.json.JSONArray
import org.json.JSONObject

data class TournamentBackupBundle(
    val tournament: TournamentEntity,
    val teams: List<TeamEntity>,
    val players: List<PlayerEntity>,
    val matches: List<MatchEntity>,
    val balls: List<BallEventEntity>,
    val members: List<TournamentMemberEntity>,
    val logs: List<AuditLogEntity>,
    val playerMatchStats: List<PlayerMatchStatEntity> = emptyList()
)

object BackupSerializer {

    fun exportTournamentJson(
        bundle: TournamentBackupBundle,
        redactEditorCode: Boolean = false
    ): String {
        val root = JSONObject()
        root.put("schemaVersion", 4)
        root.put("exportedAt", System.currentTimeMillis())

        val t = bundle.tournament
        root.put("tournament", JSONObject().apply {
            put("ownerUserId", t.ownerUserId)
            put("name", t.name)
            put("logoEmoji", t.logoEmoji)
            put("organizationName", t.organizationName)
            put("pitchType", t.pitchType.name)
            put("scoringMode", t.scoringMode.name)
            put("format", t.format.name)
            put("oversPerMatch", t.oversPerMatch)
            put("playersPerSide", t.playersPerSide)
            put("squadSize", t.squadSize)
            put("allOutWickets", t.allOutWickets)
            put("maxOversPerBowler", t.maxOversPerBowler)
            put("maxTeams", t.maxTeams)
            put("groupCount", t.groupCount)
            put("rulesSummary", CricketStatsEngine.formatRulesSummary(t))
            put("pointsWin", t.pointsWin)
            put("pointsTie", t.pointsTie)
            put("pointsLoss", t.pointsLoss)
            put("pointsAbandoned", t.pointsAbandoned)
            put("pointsWalkover", t.pointsWalkover)
            put("tiebreakerOrder", t.tiebreakerOrder)
            put("tieRule", t.tieRule.name)
            put("matchesPerPair", t.matchesPerPair)
            put("playoffType", t.playoffType.name)
            put("playoffTeamsCount", t.playoffTeamsCount)
            put("leaguePlayersPerSide", t.leaguePlayersPerSide)
            put("leagueSquadSize", t.leagueSquadSize)
            put("leagueOvers", t.leagueOvers)
            put("playoffPlayersPerSide", t.playoffPlayersPerSide)
            put("playoffSquadSize", t.playoffSquadSize)
            put("playoffOvers", t.playoffOvers)
            put("finalPlayersPerSide", t.finalPlayersPerSide)
            put("finalSquadSize", t.finalSquadSize)
            put("finalOvers", t.finalOvers)
            put("mottBattingWeight", t.mottBattingWeight)
            put("mottBowlingWeight", t.mottBowlingWeight)
            put("mottBowlingWicketShare", t.mottBowlingWicketShare)
            put("mottBowlingEconomyShare", t.mottBowlingEconomyShare)
            put("mottFinalMultiplier", t.mottFinalMultiplier)
            put("tournamentCode", t.tournamentCode)
            put("editorCode", if (redactEditorCode) "" else t.editorCode)
            put("viewerCode", t.viewerCode)
            put("startDateLabel", t.startDateLabel)
            put("location", t.location)
        })

        root.put("teams", JSONArray().apply {
            bundle.teams.forEach { team ->
                put(JSONObject().apply {
                    put("id", team.id)
                    put("name", team.name)
                    put("shortCode", team.shortCode)
                    put("logoEmoji", team.logoEmoji)
                    put("captainName", team.captainName)
                    put("groupName", team.groupName)
                    put("homeGround", team.homeGround)
                    put("played", team.played)
                    put("won", team.won)
                    put("lost", team.lost)
                    put("tiedOrAbandoned", team.tiedOrAbandoned)
                    put("points", team.points)
                    put("runsFor", team.runsFor)
                    put("ballsFaced", team.ballsFaced)
                    put("runsAgainst", team.runsAgainst)
                    put("ballsBowled", team.ballsBowled)
                })
            }
        })

        root.put("players", JSONArray().apply {
            bundle.players.forEach { p ->
                put(JSONObject().apply {
                    put("id", p.id)
                    put("teamId", p.teamId)
                    put("name", p.name)
                    put("jerseyNumber", p.jerseyNumber)
                    put("role", p.role.name)
                    put("battingStyle", p.battingStyle)
                    put("bowlingStyle", p.bowlingStyle)
                    put("photoEmoji", p.photoEmoji)
                    put("isCaptain", p.isCaptain)
                    put("matchesPlayed", p.matchesPlayed)
                    put("inningsBatted", p.inningsBatted)
                    put("runsScored", p.runsScored)
                    put("ballsFaced", p.ballsFaced)
                    put("fours", p.fours)
                    put("sixes", p.sixes)
                    put("notOuts", p.notOuts)
                    put("highestScore", p.highestScore)
                    put("ballsBowled", p.ballsBowled)
                    put("runsConceded", p.runsConceded)
                    put("wicketsTaken", p.wicketsTaken)
                    put("bestBowlingWickets", p.bestBowlingWickets)
                    put("bestBowlingRuns", p.bestBowlingRuns)
                    put("playerOfMatchCount", p.playerOfMatchCount)
                })
            }
        })

        root.put("matches", JSONArray().apply {
            bundle.matches.forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id)
                    put("matchNumber", m.matchNumber)
                    put("stage", m.stage.name)
                    put("groupName", m.groupName)
                    put("teamAId", m.teamAId)
                    put("teamBId", m.teamBId)
                    put("teamAName", m.teamAName)
                    put("teamBName", m.teamBName)
                    put("venue", m.venue)
                    put("scheduledDate", m.scheduledDate)
                    put("scheduledTime", m.scheduledTime)
                    put("oversLimit", m.oversLimit)
                    put("playersPerSideSnapshot", m.playersPerSideSnapshot)
                    put("squadSizeSnapshot", m.squadSizeSnapshot)
                    put("allOutWicketsSnapshot", m.allOutWicketsSnapshot)
                    put("maxOversPerBowlerSnapshot", m.maxOversPerBowlerSnapshot)
                    put("scoringMode", m.scoringMode.name)
                    put("status", m.status.name)
                    put("currentInnings", m.currentInnings)
                    put("battingFirstTeamId", m.battingFirstTeamId)
                    put("teamARuns", m.teamARuns)
                    put("teamAWickets", m.teamAWickets)
                    put("teamABalls", m.teamABalls)
                    put("teamAExtras", m.teamAExtras)
                    put("teamBRuns", m.teamBRuns)
                    put("teamBWickets", m.teamBWickets)
                    put("teamBBalls", m.teamBBalls)
                    put("teamBExtras", m.teamBExtras)
                    put("activeStrikerId", m.activeStrikerId)
                    put("activeNonStrikerId", m.activeNonStrikerId)
                    put("activeBowlerId", m.activeBowlerId)
                    put("teamAPlayingIds", m.teamAPlayingIds)
                    put("teamBPlayingIds", m.teamBPlayingIds)
                    put("winnerTeamId", m.winnerTeamId)
                    put("playerOfMatchId", m.playerOfMatchId)
                    put("playerOfMatchName", m.playerOfMatchName)
                    put("resultSummary", m.resultSummary)
                })
            }
        })

        root.put("balls", JSONArray().apply {
            bundle.balls.forEach { b ->
                put(JSONObject().apply {
                    put("matchId", b.matchId)
                    put("innings", b.innings)
                    put("sequenceNumber", b.sequenceNumber)
                    put("overNumber", b.overNumber)
                    put("ballInOver", b.ballInOver)
                    put("strikerId", b.strikerId)
                    put("nonStrikerId", b.nonStrikerId)
                    put("bowlerId", b.bowlerId)
                    put("runsOffBat", b.runsOffBat)
                    put("extraRuns", b.extraRuns)
                    put("extraType", b.extraType.name)
                    put("isWicket", b.isWicket)
                    put("wicketType", b.wicketType.name)
                    put("dismissedPlayerId", b.dismissedPlayerId)
                    put("isBoundaryFour", b.isBoundaryFour)
                    put("isBoundarySix", b.isBoundarySix)
                    put("summaryLabel", b.summaryLabel)
                })
            }
        })

        root.put("playerMatchStats", JSONArray().apply {
            bundle.playerMatchStats.forEach { st ->
                put(JSONObject().apply {
                    put("matchId", st.matchId)
                    put("teamId", st.teamId)
                    put("playerId", st.playerId)
                    put("playerName", st.playerName)
                    put("innings", st.innings)
                    put("didBat", st.didBat)
                    put("runsScored", st.runsScored)
                    put("ballsFaced", st.ballsFaced)
                    put("fours", st.fours)
                    put("sixes", st.sixes)
                    put("isNotOut", st.isNotOut)
                    put("didBowl", st.didBowl)
                    put("ballsBowled", st.ballsBowled)
                    put("runsConceded", st.runsConceded)
                    put("wicketsTaken", st.wicketsTaken)
                })
            }
        })

        return root.toString(2)
    }

    fun parseTournamentJson(rawJson: String, currentUserId: Long): TournamentBackupBundle {
        val root = JSONObject(rawJson)
        val tObj = root.getJSONObject("tournament")

        val playersPerSideVal = tObj.optInt("playersPerSide", 11)
        val parsedOvers = tObj.optInt("oversPerMatch", 20)
        val parsedPitch = runCatching { PitchType.valueOf(tObj.optString("pitchType")) }.getOrDefault(PitchType.FULL_PITCH)
        val parsedAllOut = tObj.optInt("allOutWickets", (playersPerSideVal - 1).coerceAtLeast(1))
        val parsedMaxBowl = tObj.optInt("maxOversPerBowler", 4)
        val tournament = TournamentEntity(
            ownerUserId = currentUserId,
            name = tObj.getString("name"),
            logoEmoji = tObj.optString("logoEmoji", "🏆"),
            organizationName = tObj.optString("organizationName", ""),
            pitchType = parsedPitch,
            scoringMode = runCatching { ScoringMode.valueOf(tObj.optString("scoringMode")) }.getOrDefault(ScoringMode.BALL_BY_BALL),
            format = runCatching { TournamentFormat.valueOf(tObj.optString("format")) }.getOrDefault(TournamentFormat.LEAGUE),
            oversPerMatch = parsedOvers,
            playersPerSide = playersPerSideVal,
            squadSize = tObj.optInt("squadSize", 15),
            allOutWickets = parsedAllOut,
            maxOversPerBowler = parsedMaxBowl,
            maxTeams = tObj.optInt("maxTeams", 8),
            groupCount = tObj.optInt("groupCount", 2),
            rulesSummary = CricketStatsEngine.formatRulesSummary(
                oversPerMatch = parsedOvers,
                pitchType = parsedPitch,
                playersPerSide = playersPerSideVal,
                allOutWickets = parsedAllOut,
                maxOversPerBowler = parsedMaxBowl
            ),
            pointsWin = tObj.optInt("pointsWin", 2),
            pointsTie = tObj.optInt("pointsTie", 1),
            pointsLoss = tObj.optInt("pointsLoss", 0),
            pointsAbandoned = tObj.optInt("pointsAbandoned", 1),
            pointsWalkover = tObj.optInt("pointsWalkover", 2),
            tiebreakerOrder = tObj.optString("tiebreakerOrder", "POINTS,WINS,NRR,H2H,NAME"),
            tieRule = runCatching { TieRule.valueOf(tObj.optString("tieRule")) }.getOrDefault(TieRule.SHARE_POINTS),
            matchesPerPair = tObj.optInt("matchesPerPair", 1),
            playoffType = runCatching { PlayoffType.valueOf(tObj.optString("playoffType")) }.getOrDefault(PlayoffType.SEMI_FINAL),
            playoffTeamsCount = tObj.optInt("playoffTeamsCount", 4),
            leaguePlayersPerSide = tObj.optInt("leaguePlayersPerSide", 0),
            leagueSquadSize = tObj.optInt("leagueSquadSize", 0),
            leagueOvers = tObj.optInt("leagueOvers", 0),
            playoffPlayersPerSide = tObj.optInt("playoffPlayersPerSide", 0),
            playoffSquadSize = tObj.optInt("playoffSquadSize", 0),
            playoffOvers = tObj.optInt("playoffOvers", 0),
            finalPlayersPerSide = tObj.optInt("finalPlayersPerSide", 0),
            finalSquadSize = tObj.optInt("finalSquadSize", 0),
            finalOvers = tObj.optInt("finalOvers", 0),
            mottBattingWeight = tObj.optDouble("mottBattingWeight", 1.0),
            mottBowlingWeight = tObj.optDouble("mottBowlingWeight", 1.0),
            mottBowlingWicketShare = tObj.optDouble("mottBowlingWicketShare", 0.6),
            mottBowlingEconomyShare = tObj.optDouble("mottBowlingEconomyShare", 0.4),
            mottFinalMultiplier = tObj.optDouble("mottFinalMultiplier", 1.5),
            tournamentCode = tObj.optString("tournamentCode").trim().takeIf { it.isNotBlank() }
                ?: AuthSecurity.generateCode("CM"),
            editorCode = tObj.optString("editorCode").trim().takeIf { it.isNotBlank() }
                ?: AuthSecurity.generateCode("ED"),
            viewerCode = tObj.optString("viewerCode").trim().takeIf { it.isNotBlank() }
                ?: AuthSecurity.generateCode("VW"),
            startDateLabel = tObj.optString("startDateLabel", "2026-05-01"),
            location = tObj.optString("location", "Main Ground")
        )

        val teamsArr = root.optJSONArray("teams") ?: JSONArray()
        val teams = (0 until teamsArr.length()).map { idx ->
            val o = teamsArr.getJSONObject(idx)
            TeamEntity(
                id = o.optLong("id", idx.toLong() + 1),
                tournamentId = 0,
                name = o.getString("name"),
                shortCode = o.optString("shortCode", "TM"),
                logoEmoji = o.optString("logoEmoji", "🏏"),
                captainName = o.optString("captainName", ""),
                groupName = o.optString("groupName", "Group A"),
                homeGround = o.optString("homeGround", ""),
                played = o.optInt("played", 0),
                won = o.optInt("won", 0),
                lost = o.optInt("lost", 0),
                tiedOrAbandoned = o.optInt("tiedOrAbandoned", 0),
                points = o.optInt("points", 0),
                runsFor = o.optInt("runsFor", 0),
                ballsFaced = o.optInt("ballsFaced", 0),
                runsAgainst = o.optInt("runsAgainst", 0),
                ballsBowled = o.optInt("ballsBowled", 0)
            )
        }

        val playersArr = root.optJSONArray("players") ?: JSONArray()
        val players = (0 until playersArr.length()).map { idx ->
            val o = playersArr.getJSONObject(idx)
            PlayerEntity(
                id = o.optLong("id", idx.toLong() + 1),
                tournamentId = 0,
                teamId = o.getLong("teamId"),
                name = o.getString("name"),
                jerseyNumber = o.optInt("jerseyNumber", 1),
                role = runCatching { PlayerRole.valueOf(o.optString("role")) }.getOrDefault(PlayerRole.ALL_ROUNDER),
                battingStyle = o.optString("battingStyle", "Right-hand Bat"),
                bowlingStyle = o.optString("bowlingStyle", "Right-arm Medium"),
                photoEmoji = o.optString("photoEmoji", "🧑"),
                isCaptain = o.optBoolean("isCaptain", false),
                matchesPlayed = o.optInt("matchesPlayed", 0),
                inningsBatted = o.optInt("inningsBatted", 0),
                runsScored = o.optInt("runsScored", 0),
                ballsFaced = o.optInt("ballsFaced", 0),
                fours = o.optInt("fours", 0),
                sixes = o.optInt("sixes", 0),
                notOuts = o.optInt("notOuts", 0),
                highestScore = o.optInt("highestScore", 0),
                ballsBowled = o.optInt("ballsBowled", 0),
                runsConceded = o.optInt("runsConceded", 0),
                wicketsTaken = o.optInt("wicketsTaken", 0),
                bestBowlingWickets = o.optInt("bestBowlingWickets", 0),
                bestBowlingRuns = o.optInt("bestBowlingRuns", 0),
                playerOfMatchCount = o.optInt("playerOfMatchCount", 0)
            )
        }

        val matchesArr = root.optJSONArray("matches") ?: JSONArray()
        val matches = (0 until matchesArr.length()).map { idx ->
            val o = matchesArr.getJSONObject(idx)
            MatchEntity(
                id = o.optLong("id", idx.toLong() + 1),
                tournamentId = 0,
                matchNumber = o.optInt("matchNumber", idx + 1),
                stage = runCatching { MatchStage.valueOf(o.optString("stage")) }.getOrDefault(MatchStage.LEAGUE),
                groupName = o.optString("groupName", "Group A"),
                teamAId = o.getLong("teamAId"),
                teamBId = o.getLong("teamBId"),
                teamAName = o.getString("teamAName"),
                teamBName = o.getString("teamBName"),
                venue = o.optString("venue", "Main Pitch"),
                scheduledDate = o.optString("scheduledDate", "Today"),
                scheduledTime = o.optString("scheduledTime", "15:00"),
                oversLimit = o.optInt("oversLimit", 10),
                playersPerSideSnapshot = o.optInt("playersPerSideSnapshot", 0),
                squadSizeSnapshot = o.optInt("squadSizeSnapshot", 0),
                allOutWicketsSnapshot = o.optInt("allOutWicketsSnapshot", 0),
                maxOversPerBowlerSnapshot = o.optInt("maxOversPerBowlerSnapshot", 0),
                scoringMode = runCatching { ScoringMode.valueOf(o.optString("scoringMode")) }.getOrDefault(ScoringMode.BALL_BY_BALL),
                status = runCatching { MatchStatus.valueOf(o.optString("status")) }.getOrDefault(MatchStatus.UPCOMING),
                currentInnings = o.optInt("currentInnings", 1),
                battingFirstTeamId = o.optLong("battingFirstTeamId", 0),
                teamARuns = o.optInt("teamARuns", 0),
                teamAWickets = o.optInt("teamAWickets", 0),
                teamABalls = o.optInt("teamABalls", 0),
                teamAExtras = o.optInt("teamAExtras", 0),
                teamBRuns = o.optInt("teamBRuns", 0),
                teamBWickets = o.optInt("teamBWickets", 0),
                teamBBalls = o.optInt("teamBBalls", 0),
                teamBExtras = o.optInt("teamBExtras", 0),
                activeStrikerId = o.optLong("activeStrikerId", 0),
                activeNonStrikerId = o.optLong("activeNonStrikerId", 0),
                activeBowlerId = o.optLong("activeBowlerId", 0),
                teamAPlayingIds = o.optString("teamAPlayingIds", ""),
                teamBPlayingIds = o.optString("teamBPlayingIds", ""),
                winnerTeamId = o.optLong("winnerTeamId", 0),
                playerOfMatchId = o.optLong("playerOfMatchId", 0),
                playerOfMatchName = o.optString("playerOfMatchName", ""),
                resultSummary = o.optString("resultSummary", "")
            )
        }

        val ballsArr = root.optJSONArray("balls") ?: JSONArray()
        val balls = (0 until ballsArr.length()).map { idx ->
            val o = ballsArr.getJSONObject(idx)
            BallEventEntity(
                tournamentId = 0,
                matchId = o.getLong("matchId"),
                innings = o.optInt("innings", 1),
                sequenceNumber = o.optInt("sequenceNumber", idx + 1),
                overNumber = o.optInt("overNumber", 0),
                ballInOver = o.optInt("ballInOver", 1),
                strikerId = o.optLong("strikerId", 0),
                nonStrikerId = o.optLong("nonStrikerId", 0),
                bowlerId = o.optLong("bowlerId", 0),
                runsOffBat = o.optInt("runsOffBat", 0),
                extraRuns = o.optInt("extraRuns", 0),
                extraType = runCatching { ExtraType.valueOf(o.optString("extraType")) }.getOrDefault(ExtraType.NONE),
                isWicket = o.optBoolean("isWicket", false),
                wicketType = runCatching { WicketType.valueOf(o.optString("wicketType")) }.getOrDefault(WicketType.NONE),
                dismissedPlayerId = o.optLong("dismissedPlayerId", 0),
                isBoundaryFour = o.optBoolean("isBoundaryFour", false),
                isBoundarySix = o.optBoolean("isBoundarySix", false),
                summaryLabel = o.optString("summaryLabel", "0")
            )
        }

        val statsArr = root.optJSONArray("playerMatchStats") ?: JSONArray()
        val parsedStats = (0 until statsArr.length()).map { idx ->
            val o = statsArr.getJSONObject(idx)
            PlayerMatchStatEntity(
                tournamentId = 0,
                matchId = o.getLong("matchId"),
                teamId = o.getLong("teamId"),
                playerId = o.getLong("playerId"),
                playerName = o.optString("playerName", ""),
                innings = o.optInt("innings", 1),
                didBat = o.optBoolean("didBat", false),
                runsScored = o.optInt("runsScored", 0),
                ballsFaced = o.optInt("ballsFaced", 0),
                fours = o.optInt("fours", 0),
                sixes = o.optInt("sixes", 0),
                isNotOut = o.optBoolean("isNotOut", false),
                didBowl = o.optBoolean("didBowl", false),
                ballsBowled = o.optInt("ballsBowled", 0),
                runsConceded = o.optInt("runsConceded", 0),
                wicketsTaken = o.optInt("wicketsTaken", 0)
            )
        }

        return TournamentBackupBundle(
            tournament = tournament,
            teams = teams,
            players = players,
            matches = matches,
            balls = balls,
            members = listOf(
                TournamentMemberEntity(
                    tournamentId = 0,
                    userId = currentUserId,
                    userName = "Restored Owner",
                    userEmail = "",
                    role = UserRole.OWNER,
                    canEditTeams = true,
                    canEditSchedule = true,
                    canScore = true
                )
            ),
            logs = listOf(
                AuditLogEntity(
                    tournamentId = 0,
                    actorName = "Backup Restore",
                    actionTitle = "Tournament Restored from JSON",
                    details = "Restored ${teams.size} teams and ${matches.size} matches."
                )
            ),
            playerMatchStats = parsedStats
        )
    }
}
