# Firebase Cloud Sync Setup Guide (Cricket Manager)

Cricket Manager works **100% offline** immediately using Room SQLite, WorkManager, and JSON Backup/Restore.
To enable **real-time multi-device cloud sync** across phones using Firebase:

## 1. Create a Firebase Project
1. Open [console.firebase.google.com](https://console.firebase.google.com) and create a project (e.g., `cricket-manager-prod`).
2. Add an **Android App** with package name:
   - Release: `com.cricketmanager.app`
   - Debug (optional): `com.cricketmanager.app.debug`
3. Download `google-services.json` and place it at:
   `CricketManager-Android/app/google-services.json`
   *(Note: `app/build.gradle.kts` automatically detects `google-services.json` and activates the `com.google.gms.google-services` plugin.)*

## 2. Enable Firebase Products
- **Authentication**: Enable **Email/Password**.
- **Cloud Firestore**: Create database in **Production mode** and apply `firestore.rules` (included in project root):

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /tournaments/{tournamentId} {
      allow read: if true;
      allow create: if request.auth != null && request.resource.data.ownerUid == request.auth.uid;
      allow update, delete: if request.auth != null && (
        resource.data.ownerUid == request.auth.uid ||
        request.auth.uid in resource.data.editorUids
      );
      match /{subcollection=**} {
        allow read: if true;
        allow write: if request.auth != null && (
          get(/databases/$(database)/documents/tournaments/$(tournamentId)).data.ownerUid == request.auth.uid ||
          request.auth.uid in get(/databases/$(database)/documents/tournaments/$(tournamentId)).data.editorUids
        );
      }
    }
  }
}
```

## 3. Release Signing Secrets (For Play Store)
In GitHub Repository **Settings > Secrets and variables > Actions**, add:
- `SIGNING_KEYSTORE_BASE64`: Base64-encoded `.jks` keystore
- `KEYSTORE_PASSWORD`: Keystore password
- `KEY_ALIAS`: Key alias
- `KEY_PASSWORD`: Key password

Then run the **Build Signed Release APK & AAB** workflow manually from the **Actions** tab.
