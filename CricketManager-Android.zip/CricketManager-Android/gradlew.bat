@rem
@rem Copyright 2015 the original author or authors.
@rem

@if "%DEBUG%"=="" @echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%
set WRAPPER_JAR=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar

if exist "%WRAPPER_JAR%" (
    java -Xmx64m -Xms64m -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
) else (
    where gradle >nul 2>&1
    if %errorlevel%==0 (
        gradle %*
    ) else (
        echo Error: gradle-wrapper.jar not found and gradle is not on PATH.
        exit /b 1
    )
)

endlocal
